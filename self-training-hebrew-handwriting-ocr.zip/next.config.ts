import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // tesseract.js רץ בשרת (Node) ומוטען ישירות מ-node_modules, בלי bundling
  serverExternalPackages: ["tesseract.js", "tesseract.js-core", "onnxruntime-node", "jpeg-js"],
};

export default nextConfig;
