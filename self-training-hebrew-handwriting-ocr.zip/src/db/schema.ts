import {
  pgTable,
  serial,
  integer,
  text,
  timestamp,
  jsonb,
  real,
  boolean,
  primaryKey,
  index,
} from "drizzle-orm/pg-core";

/** דף סרוק (תמונה ב-base64) */
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  width: integer("width").notNull().default(0),
  height: integer("height").notNull().default(0),
  imageBase64: text("image_base64").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** שורה שזוהתה בדף */
export const lines = pgTable(
  "lines",
  {
    id: serial("id").primaryKey(),
    documentId: integer("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    idx: integer("idx").notNull(),
    x: integer("x").notNull().default(0),
    y: integer("y").notNull().default(0),
    w: integer("w").notNull().default(0),
    h: integer("h").notNull().default(0),
    imageBase64: text("image_base64"),
    rawText: text("raw_text").notNull().default(""),
    text: text("text").notNull().default(""),
    status: text("status").notNull().default("pending"),
    confidence: real("confidence").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("lines_doc_idx").on(t.documentId, t.idx)],
);

/** גליף (אות) שנחתך משורה, עם התווית שהמשתמש אישר — זה מה שמאמן את המודל */
export const glyphs = pgTable(
  "glyphs",
  {
    id: serial("id").primaryKey(),
    documentId: integer("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    lineId: integer("line_id").references(() => lines.id, { onDelete: "cascade" }),
    label: text("label").notNull(),
    bitmap: text("bitmap").notNull(),
    aspect: real("aspect").notNull().default(1),
    gx: integer("gx").notNull().default(0),
    spaceBefore: boolean("space_before").notNull().default(false),
    source: text("source").notNull().default("user"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("glyphs_label_idx").on(t.label), index("glyphs_doc_idx").on(t.documentId)],
);

/** מודל שפה: מילים */
export const lmWords = pgTable("lm_words", {
  word: text("word").primaryKey(),
  count: integer("count").notNull().default(0),
});

/** מודל שפה: צמדי מילים */
export const lmBigrams = pgTable(
  "lm_bigrams",
  {
    w1: text("w1").notNull(),
    w2: text("w2").notNull(),
    count: integer("count").notNull().default(0),
  },
  (t) => [primaryKey({ columns: [t.w1, t.w2] })],
);

/** מודל שפה: n-grams של תווים (הקשר תווי עברי) */
export const lmChars = pgTable(
  "lm_chars",
  {
    ngram: text("ngram").primaryKey(),
    count: integer("count").notNull().default(0),
  },
);

/** תיקונים חוזרים: מילה שגויה -> מילה נכונה */
export const substitutions = pgTable(
  "substitutions",
  {
    wrong: text("wrong").notNull(),
    right: text("right").notNull(),
    count: integer("count").notNull().default(0),
  },
  (t) => [primaryKey({ columns: [t.wrong, t.right] })],
);

/** גרסאות מודל מאומן (snapshot) */
export const modelVersions = pgTable("model_versions", {
  id: serial("id").primaryKey(),
  version: integer("version").notNull(),
  samples: integer("samples").notNull().default(0),
  classes: integer("classes").notNull().default(0),
  accuracy: real("accuracy").notNull().default(0),
  payload: jsonb("payload").notNull(),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
