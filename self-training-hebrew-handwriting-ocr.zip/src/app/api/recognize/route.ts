import { recognizeJpeg } from "@/lib/mishkefet/engine";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** זיהוי שורות עם Mishkefet-v1 (ONNX מקומי, בלי אינטרנט) */
export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as { lines?: { imageBase64?: string }[] } | null;
  const items = (body?.lines ?? []).filter((l) => typeof l?.imageBase64 === "string" && l.imageBase64.length > 0);
  if (!items.length) return Response.json({ error: "אין שורות לזיהוי" }, { status: 400 });
  try {
    const results: { text: string; confidence: number }[] = [];
    let round = 0;
    for (const item of items) {
      const r = await recognizeJpeg(Buffer.from(item.imageBase64 as string, "base64"));
      round = r.round;
      results.push({ text: r.text, confidence: r.confidence });
    }
    return Response.json({ results, round, engine: "mishkefet-v1" });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return Response.json({ error: `Mishkefet-v1 נכשל: ${message}` }, { status: 500 });
  }
}
