import { db } from "@/db";
import { glyphs, lines } from "@/db/schema";
import { eq } from "drizzle-orm";
import { recordCorrectedText, recordSubstitutions } from "@/lib/lmstore";
import { syncDataset } from "@/lib/dataset";
import type { GlyphPayload } from "@/lib/apiTypes";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const lineId = Number(id);
  if (!Number.isFinite(lineId)) return Response.json({ error: "id שגוי" }, { status: 400 });

  const body = (await request.json()) as {
    text?: string;
    rawText?: string;
    status?: string;
    confidence?: number;
    train?: boolean;
    glyphs?: GlyphPayload[];
  };

  const [existing] = await db
    .select({ id: lines.id, documentId: lines.documentId, rawText: lines.rawText })
    .from(lines)
    .where(eq(lines.id, lineId))
    .limit(1);
  if (!existing) return Response.json({ error: "שורה לא נמצאה" }, { status: 404 });

  const newText = typeof body.text === "string" ? body.text : undefined;
  await db
    .update(lines)
    .set({
      ...(newText !== undefined ? { text: newText } : {}),
      ...(body.status ? { status: body.status } : {}),
      ...(typeof body.confidence === "number" ? { confidence: body.confidence } : {}),
      updatedAt: new Date(),
    })
    .where(eq(lines.id, lineId));

  let stored = 0;
  if (body.train && body.glyphs?.length) {
    await db.delete(glyphs).where(eq(glyphs.lineId, lineId));
    const rows = body.glyphs
      .filter((g) => g.label && g.bitmap)
      .slice(0, 400)
      .map((g) => ({
        documentId: existing.documentId,
        lineId,
        label: g.label,
        bitmap: g.bitmap,
        aspect: g.aspect ?? 1,
        gx: Math.round(g.gx ?? 0),
        spaceBefore: Boolean(g.spaceBefore),
        source: g.source ?? "user",
      }));
    if (rows.length) {
      await db.insert(glyphs).values(rows);
      stored = rows.length;
    }
  }

  if (newText !== undefined) {
    await recordCorrectedText(newText);
    const raw = typeof body.rawText === "string" ? body.rawText : existing.rawText;
    if (raw && raw !== newText) await recordSubstitutions(raw, newText);
  }

  await syncDataset().catch(() => undefined);
  return Response.json({ ok: true, stored });
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const lineId = Number(id);
  if (!Number.isFinite(lineId)) return Response.json({ error: "id שגוי" }, { status: 400 });
  await db.delete(lines).where(eq(lines.id, lineId));
  await syncDataset().catch(() => undefined);
  return Response.json({ ok: true });
}
