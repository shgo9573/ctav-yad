import { and, desc, eq, isNotNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { documents, lines } from "@/db/schema";
import { DATASET_DIR } from "@/lib/dataset";
import { MODEL_LICENSE, MODEL_NAME } from "@/lib/mishkefet/engine";
import { currentRound, getJob, readRounds, startAdapt, type Sample } from "@/lib/mishkefet/train";
import type { AdaptStatus } from "@/lib/apiTypes";
import path from "node:path";

export const dynamic = "force-dynamic";

/** מצב האימון, הגרסאות והנתונים */
export async function GET() {
  const [edited] = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(lines)
    .where(and(eq(lines.status, "edited"), isNotNull(lines.imageBase64)));
  const [trainable] = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(lines)
    .where(and(eq(lines.status, "edited"), isNotNull(lines.imageBase64), sql`${lines.text} <> ''`));
  const [pages] = await db.select({ c: sql<number>`count(*)::int` }).from(documents);

  const body: AdaptStatus = {
    job: getJob(),
    head: currentRound(),
    rounds: readRounds().slice(-30).reverse(),
    dataset: {
      dir: path.relative(process.cwd(), DATASET_DIR) || "data/dataset",
      lines: Number(edited?.c ?? 0),
      pages: Number(pages?.c ?? 0),
      trainable: Number(trainable?.c ?? 0),
    },
    base: { name: MODEL_NAME, classes: 198, license: MODEL_LICENSE },
  };
  return Response.json(body);
}

/** מתחיל סבב אימון של ראש ה-CTC על כל השורות שתוקנו ונשמרו */
export async function POST() {
  if (getJob().running) return Response.json({ started: false, job: getJob() });
  const rows = await db
    .select({ id: lines.id, text: lines.text, imageBase64: lines.imageBase64 })
    .from(lines)
    .where(and(eq(lines.status, "edited"), isNotNull(lines.imageBase64)))
    .orderBy(desc(lines.id))
    .limit(400);
  const samples: Sample[] = rows
    .filter((r) => r.text.trim().length > 0 && r.imageBase64)
    .map((r) => ({ id: r.id, text: r.text, jpeg: Buffer.from(r.imageBase64 as string, "base64") }));
  if (!samples.length) {
    return Response.json({ error: "אין שורות מתוקנות לאימון. תקן ושמור שורה קודם." }, { status: 400 });
  }
  const job = startAdapt(samples);
  return Response.json({ started: true, job });
}
