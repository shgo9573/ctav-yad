import { db } from "@/db";
import { documents, lines } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import type { SaveLinePayload } from "@/lib/apiTypes";
import { savePageImage } from "@/lib/dataset";

export const dynamic = "force-dynamic";

export async function GET() {
  const docs = await db
    .select({
      id: documents.id,
      name: documents.name,
      width: documents.width,
      height: documents.height,
      createdAt: documents.createdAt,
    })
    .from(documents)
    .orderBy(desc(documents.id))
    .limit(50);
  const counts = await db
    .select({ documentId: lines.documentId, c: sql<number>`count(*)::int` })
    .from(lines)
    .groupBy(lines.documentId);
  const countMap = new Map(counts.map((c) => [c.documentId, Number(c.c)]));
  return Response.json({
    documents: docs.map((d) => ({
      id: d.id,
      name: d.name,
      width: d.width,
      height: d.height,
      createdAt: d.createdAt.toISOString(),
      lineCount: countMap.get(d.id) ?? 0,
    })),
  });
}

export async function POST(request: Request) {
  const body = (await request.json()) as {
    name?: string;
    width?: number;
    height?: number;
    imageBase64?: string;
    lines?: SaveLinePayload[];
  };
  if (!body.imageBase64) return Response.json({ error: "imageBase64 חסר" }, { status: 400 });

  const [doc] = await db
    .insert(documents)
    .values({
      name: body.name?.slice(0, 200) || "דף ללא שם",
      width: Math.round(body.width ?? 0),
      height: Math.round(body.height ?? 0),
      imageBase64: body.imageBase64,
    })
    .returning({ id: documents.id });

  // הסריקה המלאה נשמרת גם בתיקיית הנתונים (data/dataset/pages)
  try {
    savePageImage(doc.id, body.name || "page", body.imageBase64);
  } catch {
    /* שמירה לתיקייה היא תוספת; לא מפילה את הבקשה */
  }

  const rows = (body.lines ?? []).map((l) => ({
    documentId: doc.id,
    idx: l.idx,
    x: Math.round(l.x),
    y: Math.round(l.y),
    w: Math.round(l.w),
    h: Math.round(l.h),
    imageBase64: l.imageBase64 ?? null,
    rawText: l.rawText ?? "",
    text: l.text ?? "",
    status: l.status || "pending",
    confidence: l.confidence ?? 0,
  }));
  let inserted: { id: number; idx: number }[] = [];
  if (rows.length) {
    inserted = await db.insert(lines).values(rows).returning({ id: lines.id, idx: lines.idx });
  }
  return Response.json({ id: doc.id, lines: inserted });
}
