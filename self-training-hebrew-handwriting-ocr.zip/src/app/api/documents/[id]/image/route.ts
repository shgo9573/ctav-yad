import { db } from "@/db";
import { documents } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const docId = Number(id);
  if (!Number.isFinite(docId)) return new Response("bad id", { status: 400 });
  const [row] = await db
    .select({ imageBase64: documents.imageBase64 })
    .from(documents)
    .where(eq(documents.id, docId))
    .limit(1);
  if (!row) return new Response("not found", { status: 404 });
  const bytes = Uint8Array.from(Buffer.from(row.imageBase64, "base64"));
  return new Response(bytes, {
    headers: {
      "Content-Type": "image/jpeg",
      "Cache-Control": "private, max-age=86400",
    },
  });
}
