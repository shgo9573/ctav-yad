import { db } from "@/db";
import { documents, glyphs, lines } from "@/db/schema";
import { syncDataset } from "@/lib/dataset";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const docId = Number(id);
  if (!Number.isFinite(docId)) return Response.json({ error: "id שגוי" }, { status: 400 });

  const [doc] = await db.select().from(documents).where(eq(documents.id, docId)).limit(1);
  if (!doc) return Response.json({ error: "מסמך לא נמצא" }, { status: 404 });

  const rows = await db
    .select({
      id: lines.id,
      idx: lines.idx,
      x: lines.x,
      y: lines.y,
      w: lines.w,
      h: lines.h,
      imageBase64: lines.imageBase64,
      rawText: lines.rawText,
      text: lines.text,
      status: lines.status,
      confidence: lines.confidence,
    })
    .from(lines)
    .where(eq(lines.documentId, docId))
    .orderBy(asc(lines.idx));

  const glyphRows = await db
    .select({
      lineId: glyphs.lineId,
      label: glyphs.label,
      bitmap: glyphs.bitmap,
      aspect: glyphs.aspect,
      gx: glyphs.gx,
      spaceBefore: glyphs.spaceBefore,
    })
    .from(glyphs)
    .where(eq(glyphs.documentId, docId));
  const glyphsByLine: Record<
    string,
    { label: string; bitmap: string; aspect: number; gx: number; spaceBefore: boolean }[]
  > = {};
  for (const g of glyphRows) {
    if (g.lineId === null) continue;
    const key = String(g.lineId);
    (glyphsByLine[key] ??= []).push({
      label: g.label,
      bitmap: g.bitmap,
      aspect: g.aspect,
      gx: g.gx,
      spaceBefore: g.spaceBefore,
    });
  }

  return Response.json({
    id: doc.id,
    name: doc.name,
    width: doc.width,
    height: doc.height,
    createdAt: doc.createdAt.toISOString(),
    lines: rows,
    glyphsByLine,
  });
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const docId = Number(id);
  if (!Number.isFinite(docId)) return Response.json({ error: "id שגוי" }, { status: 400 });
  await db.delete(documents).where(eq(documents.id, docId));
  await syncDataset().catch(() => undefined);
  return Response.json({ ok: true });
}
