import { trainModel } from "@/lib/train";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request: Request) {
  let note = "";
  try {
    const body = (await request.json()) as { note?: string };
    note = typeof body?.note === "string" ? body.note.slice(0, 200) : "";
  } catch {
    note = "";
  }
  const result = await trainModel(note || "אימון ידני מהממשק");
  return Response.json(result);
}
