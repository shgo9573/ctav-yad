import { buildDataZip, syncDataset } from "@/lib/dataset";

export const dynamic = "force-dynamic";

/** הורדת כל תיקיית data/ (דפים, שורות מתומללות, מניפסט וגרסאות ראש) כ-ZIP */
export async function GET() {
  await syncDataset();
  const zip = buildDataZip();
  return new Response(new Uint8Array(zip), {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": 'attachment; filename="mishkefet-data.zip"',
    },
  });
}
