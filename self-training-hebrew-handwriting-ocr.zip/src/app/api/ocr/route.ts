import { recognizePageOnServer } from "@/lib/serverOcr";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

/** OCR עברי מקומי בשרת (tesseract.js + heb.traineddata מתוך public/tessdata) */
export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as { imageBase64?: string } | null;
  if (!body?.imageBase64) return Response.json({ error: "imageBase64 חסר" }, { status: 400 });
  try {
    const jpeg = Buffer.from(body.imageBase64, "base64");
    const lines = await recognizePageOnServer(jpeg);
    return Response.json({ engine: "server", lines });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return Response.json({ error: `OCR בשרת נכשל: ${message}` }, { status: 500 });
  }
}
