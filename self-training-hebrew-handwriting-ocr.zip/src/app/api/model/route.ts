import { db } from "@/db";
import { modelVersions } from "@/db/schema";
import { desc } from "drizzle-orm";
import { countGlyphs } from "@/lib/train";
import { seedWordCounts } from "@/lib/hebrew";
import type { ModelPayload } from "@/lib/model";

export const dynamic = "force-dynamic";

export async function GET() {
  const [latest] = await db.select().from(modelVersions).orderBy(desc(modelVersions.version)).limit(1);
  const glyphCount = await countGlyphs();
  if (!latest) {
    // מודל ריק: מודל שפה זרעים בלבד, כדי שהתיקון הראשון יעזור
    const seeded = [...seedWordCounts().entries()].map(([w, c]) => [w, c] as [string, number]);
    const payload: ModelPayload = {
      version: 0,
      trainedAt: "",
      samples: 0,
      accuracy: 0,
      classes: [],
      templates: [],
      lang: { words: seeded, bigrams: [], chars: [], subs: [] },
    };
    return Response.json({
      stats: { version: 0, samples: 0, classes: 0, accuracy: 0, createdAt: "", glyphCount, perLabel: [] },
      payload,
    });
  }
  const payload = latest.payload as ModelPayload;
  // מוסיפים מילים נפוצות כבסיס למודל השפה, כדי שהתיקון יעבוד גם עם מילון משתמש קטן
  const wordMap = new Map<string, number>(seedWordCounts());
  for (const [w, c] of payload.lang.words ?? []) {
    wordMap.set(w, Math.max(wordMap.get(w) ?? 0, c));
  }
  payload.lang.words = [...wordMap.entries()];
  const perLabel = (payload.classes ?? []).map((c) => ({ label: c.label, count: c.count }));
  return Response.json({
    stats: {
      version: latest.version,
      samples: latest.samples,
      classes: latest.classes,
      accuracy: latest.accuracy,
      createdAt: latest.createdAt.toISOString(),
      glyphCount,
      perLabel,
    },
    payload,
  });
}
