import TranscriberApp from "@/components/TranscriberApp";

export default function Page() {
  return <TranscriberApp />;
}
