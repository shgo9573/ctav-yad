import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "מתמלל כתב יד עברי · אימון עצמי",
  description: "תמלול כתב יד עברי מסריקת דף, עם מודל גליפים שמתאמן על כתב היד הספציפי שלך — אופליין לחלוטין.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="he" dir="rtl">
      <body className="bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
