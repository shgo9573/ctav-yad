/* בדיקת חלוקת שורות וחיתוך גליפים על תמונה בינרית סינתטית (ללא DOM) */
import { detectLineBoxes, segmentLineGlyphs, type Box } from "../lib/vision";

function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error("FAIL:", msg);
    process.exitCode = 1;
  } else {
    console.log("ok  :", msg);
  }
}

const W = 320;
const H = 140;
const ink = new Uint8Array(W * H);

function blob(cx: number, cy: number, rw: number, rh: number) {
  for (let y = cy - rh; y <= cy + rh; y++) {
    for (let x = cx - rw; x <= cx + rw; x++) {
      if (x < 0 || y < 0 || x >= W || y >= H) continue;
      const dx = (x - cx) / (rw + 0.001);
      const dy = (y - cy) / (rh + 0.001);
      if (dx * dx + dy * dy <= 1) ink[y * W + x] = 1;
    }
  }
}

function line(y: number, groups: number[][]) {
  for (const group of groups) {
    for (let x = group[0]; x <= group[1]; x++) {
      ink[(y + 2) * W + x] = 1;
      ink[(y + 6) * W + x] = 1;
      ink[(y + 10) * W + x] = 1;
      ink[(y + 14) * W + x] = 1;
      ink[(y + 18) * W + x] = 1;
    }
  }
}

// שורה 1: שתי מילים — שלוש אותיות, רווח, שתי אותיות
line(14, [[10, 20], [28, 40], [46, 56], [90, 100], [108, 118]]);
// שורה 2: מילה אחת
line(72, [[20, 34], [42, 54]]);

function main() {
  const boxes = detectLineBoxes(ink, W, H);
  assert(boxes.length === 2, `detectLineBoxes מצא 2 שורות (מצא ${boxes.length})`);
  if (boxes.length < 2) return;
  const first: Box = boxes[0];
  assert(first.y < 40 && first.y + first.h > 30, `תיבת השורה הראשונה נכונה (${JSON.stringify(first)})`);

  const glyphs = segmentLineGlyphs(ink, W, H, first);
  assert(glyphs.length === 5, `segmentLineGlyphs מצא 5 גליפים (מצא ${glyphs.length})`);
  if (glyphs.length === 5) {
    const rtlSorted = glyphs.every((g, i, arr) => i === 0 || arr[i - 1].box.x > g.box.x);
    assert(rtlSorted, "הגליפים מסודרים מימין לשמאל");
    const spaces = glyphs.map((g) => g.spaceBefore);
    assert(
      spaces[2] === true && spaces.filter(Boolean).length === 1,
      `רווח זוהה פעם אחת במקום הנכון (${JSON.stringify(spaces)})`,
    );
    assert(glyphs[0].bitmap.length > 90, "מפת הגליף מקודדת (96 תווי base64)");
    assert(glyphs[0].aspect > 0.5 && glyphs[0].aspect < 1.5, `יחס גובה-רוחב סביר (${glyphs[0].aspect.toFixed(2)})`);
  }

  const second = segmentLineGlyphs(ink, W, H, boxes[1]);
  assert(second.length === 2, `השורה השנייה — 2 גליפים (מצא ${second.length})`);
  console.log(process.exitCode ? "\n=== נכשל ===" : "\n=== בדיקות הראייה עברו ===");
}

main();
