/* בדיקת היגיון למנוע: bitmap, מודל גליפים, מודל שפה, התאמת גליפים-טקסט */
import { BM, BM_CELLS, bytesToBase64, packBitmap, unpackBitmap, base64ToBytes } from "../lib/bitmap";
import { GlyphModel, LanguageModel, type ModelPayload } from "../lib/model";
import { alignGlyphsToText } from "../lib/align";

function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error("FAIL:", msg);
    process.exitCode = 1;
  } else {
    console.log("ok  :", msg);
  }
}

function synthGlyph(seed: number, variant: number): { bitmap: string; aspect: number } {
  const bits = new Uint8Array(BM_CELLS);
  const put = (x: number, y: number) => {
    if (x >= 0 && x < BM && y >= 0 && y < BM) bits[y * BM + x] = 1;
  };
  const shapes: ((r: number) => void)[] = [
    // א — קווים אלכסוניים
    (r) => {
      for (let y = 4; y < 20; y++) put(6 + ((y - 4) * 8) / 16 + (r % 3), y);
      for (let x = 4; x < 19; x++) put(x, 14 + (r % 2));
    },
    // ב — קו עליון + קו ימני
    (r) => {
      for (let x = 4; x < 19; x++) put(x, 5 + (r % 2));
      for (let y = 5; y < 19; y++) put(17, y);
      for (let y = 12; y < 19; y++) put(6, y);
    },
    // ג — קו אופקי עליון + אלכסון
    (r) => {
      for (let x = 5; x < 18; x++) put(x, 6 + (r % 2));
      for (let y = 6; y < 19; y++) put(17 - ((y - 6) * 9) / 13, y);
    },
  ];
  shapes[seed % 3](variant);
  return { bitmap: packBitmap(bits), aspect: 0.7 + 0.1 * (seed % 3) };
}

function buildPayload(): ModelPayload {
  const labels = ["א", "ב", "ג"];
  const samples: Record<string, { bitmap: string; aspect: number }[]> = {};
  for (let s = 0; s < 3; s++) {
    samples[labels[s]] = [];
    for (let v = 0; v < 10; v++) samples[labels[s]].push(synthGlyph(s, v));
  }
  const total = Object.values(samples).reduce((a, b) => a + b.length, 0);
  const classes = Object.entries(samples).map(([label, arr]) => {
    const ink = new Float64Array(BM_CELLS);
    for (const s of arr) {
      const bits = unpackBitmap(s.bitmap);
      for (let i = 0; i < BM_CELLS; i++) ink[i] += bits[i];
    }
    const bytes = new Uint8Array(BM_CELLS);
    for (let i = 0; i < BM_CELLS; i++) bytes[i] = Math.max(1, Math.min(254, Math.round(((ink[i] + 0.6) / (arr.length + 1.2)) * 255)));
    return { label, count: arr.length, prior: arr.length / total, cells: bytesToBase64(bytes) };
  });
  const templates = Object.entries(samples).flatMap(([label, arr]) => arr.map((s) => ({ label, ...s })));
  return {
    version: 1,
    trainedAt: new Date().toISOString(),
    samples: total,
    accuracy: 0,
    classes,
    templates,
    lang: {
      words: [
        ["שלום", 12],
        ["עולם", 8],
        ["בוקר", 5],
        ["טוב", 20],
        ["ישראל", 6],
      ],
      bigrams: ["שלום|עולם|4", "בוקר|טוב|6"],
      chars: [
        ["ש", 40],
        ["לו", 18],
        ["\u0002של", 9],
        ["לום", 9],
        ["עול", 7],
        ["ולם", 7],
        ["בוק", 5],
        ["טוב", 9],
      ],
      subs: [
        ["שלו", "שלום", 3],
        ["בוקר", "בוקר", 1],
      ],
    },
  };
}

function main() {
  // base64 roundtrip
  const bytes = new Uint8Array([0, 1, 2, 250, 255, 128, 7]);
  const b64 = bytesToBase64(bytes);
  const back = base64ToBytes(b64);
  assert(Array.from(back).join(",") === Array.from(bytes).join(","), "base64 roundtrip");

  const bits = new Uint8Array(BM_CELLS);
  bits[0] = 1;
  bits[575] = 1;
  const unpacked = unpackBitmap(packBitmap(bits));
  assert(unpacked[0] === 1 && unpacked[575] === 1 && unpacked[1] === 0, "bitmap pack/unpack");

  const payload = buildPayload();
  const model = new GlyphModel(payload);
  const cands = ["א", "ב", "ג"].map((label, s) => {
    const g = synthGlyph(s, 3);
    const res = model.classify(g.bitmap, g.aspect);
    return { label, top: res[0]?.label ?? "?", score: res[0]?.score ?? 0, all: res.map((r) => r.label).join("/") };
  });
  for (const c of cands) {
    assert(c.top === c.label, `classify: ציפה ל-${c.label}, קיבל ${c.top} (${c.all})`);
  }

  const lm = new LanguageModel(payload.lang, 1);
  const words = [cands.map((c) => [{ label: c.label, score: -0.1 }]), cands.map((c) => [{ label: c.label, score: -0.1 }])];
  const beam = lm.beamWords(words[0]);
  assert(beam.length > 0 && beam[0].word.length === 1, `beamWords מחזיר מועמדים (${beam.map((b) => b.word).join(",")})`);

  const sentence = lm.bestSentence([
    { cands: [{ word: "שלום", score: -0.2 }, { word: "שלו", score: -0.3 }] },
    { cands: [{ word: "עולם", score: -0.2 }, { word: "עולם2", score: -0.25 }] },
  ]);
  assert(sentence.join(" ") === "שלום עולם", `bestSentence בוחר בצמד הנלמד (${sentence.join(" ")})`);

  const fixed = lm.correctFreeText("אני אומר שלו לכולם");
  assert(fixed.includes("שלום"), `correctFreeText מתקן למילה מהמילון (${fixed})`);

  const align = alignGlyphsToText(
    [[{ label: "א", score: -0.1 }], [{ label: "ב", score: -0.1 }], [{ label: "ג", score: -0.1 }]],
    "אבג",
  );
  assert(align.labels.join("") === "אבג", `alignGlyphsToText מתאים 1:1 (${align.labels.join("")})`);

  const align2 = alignGlyphsToText(
    [[{ label: "א", score: -0.1 }], [{ label: "ב", score: -0.1 }], [{ label: "ג", score: -0.1 }], [{ label: "ד", score: -0.1 }]],
    "אבג",
  );
  assert(align2.labels.filter(Boolean).length === 3, `alignGlyphsToText מדלג על גליף עודף (${align2.labels.join("|")})`);

  const align3 = alignGlyphsToText(
    [[{ label: "א", score: -0.1 }], [{ label: "ב", score: -0.1 }], [{ label: "ג", score: -0.1 }]],
    "אבג שלום",
  );
  assert(align3.labels.filter(Boolean).length === 3, `alignGlyphsToText מתעלם מתווים חסרים (${align3.labels.join("|")})`);

  console.log(process.exitCode ? "\n=== נכשל ===" : "\n=== כל הבדיקות עברו ===");
}

main();
