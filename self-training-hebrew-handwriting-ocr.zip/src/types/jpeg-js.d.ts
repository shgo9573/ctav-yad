declare module "jpeg-js" {
  export interface RawImageData<T> {
    width: number;
    height: number;
    data: T;
  }
  export function decode(
    buffer: Uint8Array | Buffer,
    opts?: { useTArray?: boolean; formatAsRGBA?: boolean; maxMemoryUsageInMB?: number },
  ): RawImageData<Uint8Array>;
}
