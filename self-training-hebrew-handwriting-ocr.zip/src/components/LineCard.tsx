"use client";

import type { LineState } from "@/lib/clientTypes";

function confColor(c: number): string {
  if (c >= 0.75) return "text-emerald-400";
  if (c >= 0.45) return "text-amber-400";
  return "text-rose-400";
}

type Props = {
  line: LineState;
  number: number;
  busy: boolean;
  onText: (text: string) => void;
  onSave: (train: boolean) => void;
  onRerun: () => void;
};

/** שורה: תמונת השורה למעלה, ומתחתיה תיבת התמלול הניתנת לעריכה */
export default function LineCard({ line, number, busy, onText, onSave, onRerun }: Props) {
  const conf = Math.max(0, Math.min(1, line.confidence));
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 shadow-sm transition hover:border-slate-700">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-sm">
          <span className="rounded-md bg-slate-800 px-2 py-1 font-semibold text-slate-200">שורה {number}</span>
          {line.raw && <span className={`text-xs ${confColor(conf)}`}>ביטחון {(conf * 100).toFixed(0)}%</span>}
          {line.edited ? (
            <span className="rounded bg-amber-500/15 px-2 py-0.5 text-xs text-amber-300">נערך · לא נשמר</span>
          ) : line.savedAt ? (
            <span className="rounded bg-emerald-500/15 px-2 py-0.5 text-xs text-emerald-300">נשמר לתיקיית הנתונים</span>
          ) : (
            <span className="rounded bg-slate-700/40 px-2 py-0.5 text-xs text-slate-400">חדש</span>
          )}
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onSave(false)}
            disabled={busy || !line.id}
            className="rounded-md bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-100 hover:bg-slate-700 disabled:opacity-50"
          >
            שמור שורה
          </button>
          <button
            onClick={() => onSave(true)}
            disabled={busy || !line.id}
            className="rounded-md bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500 disabled:opacity-50"
            title="שומר את השורה ומאמן את ראש המודל על כל השורות שתוקנו"
          >
            ⚡ שמור ואמן
          </button>
          <button
            onClick={onRerun}
            disabled={busy}
            className="rounded-md bg-slate-800 px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-700 disabled:opacity-50"
            title="מזהה את השורה מחדש עם המודל והראש הפעילים"
          >
            ↻ זהה מחדש
          </button>
        </div>
      </div>

      <div className="mb-2 rounded-lg border border-slate-800 bg-black/40 p-1">
        {line.imageBase64 ? (
          /* eslint-disable-next-line @next/next/no-img-element */
          <img
            src={`data:image/jpeg;base64,${line.imageBase64}`}
            alt={`שורה ${number}`}
            className="line-image block w-full rounded"
          />
        ) : (
          <div className="flex h-16 items-center justify-center text-xs text-slate-500">אין תמונה שמורה לשורה זו</div>
        )}
      </div>

      <textarea
        dir="rtl"
        value={line.text}
        onChange={(e) => onText(e.target.value)}
        rows={2}
        placeholder="תמלול השורה… תקן כאן ולחץ שמור"
        className="w-full resize-y rounded-lg border border-slate-700 bg-slate-950/70 p-3 text-xl leading-relaxed text-slate-50 outline-none focus:border-indigo-500"
      />
      {line.raw && line.raw !== line.text && (
        <div className="mt-1 text-[11px] text-slate-500">
          פלט המודל המקורי: <span dir="rtl">{line.raw}</span>
        </div>
      )}
    </div>
  );
}
