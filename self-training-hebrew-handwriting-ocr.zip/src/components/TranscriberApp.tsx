"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import LineCard from "./LineCard";
import { processPage } from "@/lib/pipeline";
import { recognizeOnServer } from "@/lib/recognize";
import type { AdaptStatus, DocumentSummary } from "@/lib/apiTypes";
import type { LineState } from "@/lib/clientTypes";
import type { OcrEngine } from "@/lib/ocr";

type Stage = "idle" | "processing" | "editing";

const ENGINE_LABEL: Record<OcrEngine, string> = {
  mishkefet: "Mishkefet-v1 (מקומי)",
  server: "tesseract heb (גיבוי, שרת)",
  browser: "tesseract heb (גיבוי, דפדפן)",
  none: "כבוי",
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export default function TranscriberApp() {
  const [stage, setStage] = useState<Stage>("idle");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<{ m: string; p: number } | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [useOcr, setUseOcr] = useState(true);
  const [ocrError, setOcrError] = useState<string | null>(null);
  const [ocrEngine, setOcrEngine] = useState<OcrEngine>("none");
  const [adapt, setAdapt] = useState<AdaptStatus | null>(null);
  const [docs, setDocs] = useState<DocumentSummary[]>([]);
  const [docId, setDocId] = useState<number | null>(null);
  const [docName, setDocName] = useState("");
  const [pageImage, setPageImage] = useState<string | null>(null);
  const [pageDims, setPageDims] = useState<[number, number]>([0, 0]);
  const [lines, setLines] = useState<LineState[]>([]);
  const [showPage, setShowPage] = useState(false);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const notify = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 6000);
  }, []);

  const refreshAdapt = useCallback(async () => {
    try {
      const r = await fetch("/api/adapt");
      setAdapt((await r.json()) as AdaptStatus);
    } catch {
      /* מתעלמים */
    }
  }, []);

  const refreshDocs = useCallback(async () => {
    try {
      const r = await fetch("/api/documents");
      const d = (await r.json()) as { documents: DocumentSummary[] };
      setDocs(d.documents);
    } catch {
      /* מתעלמים */
    }
  }, []);

  useEffect(() => {
    void refreshAdapt();
    void refreshDocs();
  }, [refreshAdapt, refreshDocs]);

  const trainingRunning = adapt?.job.running ?? false;
  const editedCount = lines.filter((l) => l.edited).length;

  const handleFiles = useCallback(
    async (fileList: FileList | File[] | null) => {
      const file = fileList?.[0];
      if (!file) return;
      setStage("processing");
      setBusy(true);
      setOcrError(null);
      setStatus({ m: "מתחיל…", p: 2 });
      try {
        const res = await processPage(file, {
          useOcr,
          onStatus: (m, p) => setStatus({ m, p }),
        });
        const r = await fetch("/api/documents", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: file.name,
            width: res.width,
            height: res.height,
            imageBase64: res.imageBase64,
            lines: res.lines.map((l) => ({
              idx: l.idx,
              x: l.box.x,
              y: l.box.y,
              w: l.box.w,
              h: l.box.h,
              imageBase64: l.imageBase64,
              rawText: l.raw,
              text: l.raw,
              status: "pending",
              confidence: l.confidence,
            })),
          }),
        });
        const data = (await r.json()) as { id: number; lines: { id: number; idx: number }[] };
        const idMap = new Map(data.lines.map((x) => [x.idx, x.id] as const));
        setLines(
          res.lines.map((l) => ({
            id: idMap.get(l.idx),
            idx: l.idx,
            imageBase64: l.imageBase64,
            box: l.box,
            text: l.raw,
            raw: l.raw,
            confidence: l.confidence,
            edited: false,
          })),
        );
        setDocId(data.id);
        setDocName(file.name);
        setPageImage(`data:image/jpeg;base64,${res.imageBase64}`);
        setPageDims([res.width, res.height]);
        setShowPage(true);
        setOcrEngine(res.ocrEngine);
        if (res.ocrError) setOcrError(res.ocrError);
        setStage("editing");
        void refreshDocs();
        notify(
          res.lines.length
            ? `זוהו ${res.lines.length} שורות. תקן כל שורה מתחתיה, ולחץ "שמור ואמן" כדי שהראש ילמד את כתב היד.`
            : "לא זוהו שורות. נסה תמונה חדה יותר או עם רקע לבן.",
        );
      } catch (err) {
        notify(err instanceof Error ? err.message : "שגיאה בעיבוד הדף");
        setStage("idle");
      } finally {
        setBusy(false);
        setStatus(null);
      }
    },
    [notify, refreshDocs, useOcr],
  );

  const patchLine = (line: LineState) =>
    fetch(`/api/lines/${line.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: line.text,
        rawText: line.raw,
        status: "edited",
        confidence: line.confidence,
      }),
    });

  /** מפעיל סבב אימון בשרת ומחכה לסיום (עם עדכון התקדמות) */
  const runAdapt = useCallback(
    async (label: string) => {
      const start = await fetch("/api/adapt", { method: "POST" });
      const sd = (await start.json()) as { error?: string };
      if (!start.ok) throw new Error(sd.error || "האימון לא התחיל");
      for (;;) {
        await sleep(1500);
        const s = (await (await fetch("/api/adapt")).json()) as AdaptStatus;
        setAdapt(s);
        if (!s.job.running) {
          if (s.job.error) notify(`האימון נכשל: ${s.job.error}`);
          else if (s.job.result)
            notify(
              s.job.result.accepted
                ? `✅ ${label}: סבב ${s.job.result.round} התקבל. ${s.job.result.reason}`
                : `⛔ ${label}: ${s.job.result.reason}. הראש הקודם נשאר פעיל.`,
            );
          return;
        }
      }
    },
    [notify],
  );

  const saveLine = useCallback(
    async (index: number, train: boolean) => {
      const line = lines[index];
      if (!line?.id) return;
      setBusy(true);
      try {
        const res = await patchLine(line);
        if (!res.ok) throw new Error("השמירה נכשלה");
        setLines((prev) => prev.map((l, i) => (i === index ? { ...l, edited: false, savedAt: new Date().toISOString() } : l)));
        if (train) await runAdapt(`שורה ${index + 1}`);
        else notify(`השורה ${index + 1} נשמרה ב-data/dataset`);
      } catch (err) {
        notify(err instanceof Error ? err.message : "שמירת השורה נכשלה");
      } finally {
        setBusy(false);
        void refreshAdapt();
      }
    },
    [lines, notify, refreshAdapt, runAdapt],
  );

  const saveAllAndTrain = useCallback(async () => {
    setBusy(true);
    try {
      let saved = 0;
      for (const line of lines) {
        if (!line.id || !line.text.trim()) continue;
        const res = await patchLine(line);
        if (res.ok) saved++;
      }
      setLines((prev) => prev.map((l) => ({ ...l, edited: false, savedAt: new Date().toISOString() })));
      setStatus({ m: `נשמרו ${saved} שורות. מאמן את הראש…`, p: 50 });
      await runAdapt("כל השורות");
    } catch (err) {
      notify(err instanceof Error ? err.message : "האימון נכשל");
    } finally {
      setBusy(false);
      setStatus(null);
      void refreshAdapt();
    }
  }, [lines, notify, refreshAdapt, runAdapt]);

  const rerunLine = useCallback(
    async (index: number) => {
      const line = lines[index];
      if (!line) return;
      setBusy(true);
      try {
        const [r] = await recognizeOnServer([line.imageBase64]);
        setLines((prev) =>
          prev.map((l, i) => (i === index ? { ...l, text: r.text, raw: r.text, confidence: r.confidence, edited: true } : l)),
        );
        notify(`השורה ${index + 1} זוהתה מחדש`);
      } catch (err) {
        notify(err instanceof Error ? err.message : "הזיהוי מחדש נכשל");
      } finally {
        setBusy(false);
      }
    },
    [lines, notify],
  );

  const rerunUnsaved = useCallback(async () => {
    const targets = lines.map((l, i) => ({ l, i })).filter((x) => !x.l.edited);
    if (!targets.length) {
      notify("אין שורות לא-ערוכות לזיהוי מחדש");
      return;
    }
    setBusy(true);
    try {
      const res = await recognizeOnServer(targets.map((t) => t.l.imageBase64), (d, t) =>
        setStatus({ m: `זיהוי מחדש: ${d} מתוך ${t}`, p: Math.round((d / t) * 100) }),
      );
      setLines((prev) =>
        prev.map((l, i) => {
          const k = targets.findIndex((t) => t.i === i);
          if (k < 0) return l;
          return { ...l, text: res[k].text, raw: res[k].text, confidence: res[k].confidence };
        }),
      );
      notify("השורות זוהו מחדש לפי הראש הפעיל");
    } catch (err) {
      notify(err instanceof Error ? err.message : "הזיהוי מחדש נכשל");
    } finally {
      setBusy(false);
      setStatus(null);
    }
  }, [lines, notify]);

  const fullText = useMemo(() => lines.map((l) => l.text.trim()).filter(Boolean).join("\n"), [lines]);

  const copyText = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(fullText);
      notify("הטקסט המלא הועתק");
    } catch {
      notify("העתקה נכשלה");
    }
  }, [fullText, notify]);

  const exportText = useCallback(() => {
    const blob = new Blob([fullText], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${docName || "תמלול"}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }, [docName, fullText]);

  const loadDoc = useCallback(
    async (id: number) => {
      setBusy(true);
      try {
        const r = await fetch(`/api/documents/${id}`);
        const d = (await r.json()) as {
          id: number;
          name: string;
          width: number;
          height: number;
          lines: {
            id: number;
            idx: number;
            x: number;
            y: number;
            w: number;
            h: number;
            imageBase64: string | null;
            rawText: string;
            text: string;
            confidence: number;
          }[];
        };
        setDocId(d.id);
        setDocName(d.name);
        setPageImage(`/api/documents/${d.id}/image`);
        setPageDims([d.width, d.height]);
        setShowPage(false);
        setLines(
          d.lines.map((l) => ({
            id: l.id,
            idx: l.idx,
            imageBase64: l.imageBase64 ?? "",
            box: { x: l.x, y: l.y, w: l.w, h: l.h },
            text: l.text || l.rawText,
            raw: l.rawText,
            confidence: l.confidence,
            edited: false,
          })),
        );
        setOcrEngine("none");
        setStage("editing");
        notify(`נטען: ${d.name}`);
      } catch {
        notify("טעינת המסמך נכשלה");
      } finally {
        setBusy(false);
      }
    },
    [notify],
  );

  const deleteDoc = useCallback(
    async (id: number) => {
      await fetch(`/api/documents/${id}`, { method: "DELETE" });
      if (docId === id) {
        setDocId(null);
        setLines([]);
        setPageImage(null);
        setStage("idle");
      }
      void refreshDocs();
    },
    [docId, refreshDocs],
  );

  const head = adapt?.head;
  const accepted = adapt?.rounds.filter((r) => r.accepted).length ?? 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-950 to-slate-900">
      <header className="border-b border-slate-800 bg-slate-950/80 px-4 py-4 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-slate-50">מתמלל כתב יד עברי · Mishkefet-v1</h1>
            <p className="text-xs text-slate-400">
              סריקה ← פיצול לשורות ← זיהוי מקומי ← תיקון ← אימון הראש על כתב היד שלך. הכל רץ על המחשב, והנתונים נשמרים
              בתיקיית <code className="text-slate-300">data/</code>.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="rounded-full bg-emerald-500/15 px-3 py-1 text-emerald-300">אופליין · בלי ענן</span>
            <span className="rounded-full bg-slate-800 px-3 py-1 text-slate-300">
              ראש מאומן: {head?.round ? `סבב ${head.round}` : "בסיס (לא אומן עדיין)"}
            </span>
          </div>
        </div>
      </header>

      {trainingRunning && adapt && (
        <div className="sticky top-0 z-40 border-b border-indigo-500/40 bg-indigo-950/90 px-4 py-2 text-sm text-indigo-100 backdrop-blur">
          <div className="mx-auto flex max-w-7xl items-center gap-3">
            <div className="size-4 animate-spin rounded-full border-2 border-indigo-800 border-t-indigo-300" />
            <span>
              מאמן את ראש ה-CTC: {adapt.job.phase} ({adapt.job.step}/{adapt.job.steps}) על {adapt.job.samples} שורות
            </span>
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-indigo-900">
              <div
                className="h-full bg-indigo-400 transition-all"
                style={{ width: `${Math.round((adapt.job.step / Math.max(1, adapt.job.steps)) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      )}

      <main className="mx-auto grid max-w-7xl gap-4 px-4 py-5 lg:grid-cols-[minmax(0,1fr)_340px]">
        <section className="min-w-0 space-y-4">
          {stage === "idle" && (
            <>
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragging(true);
                }}
                onDragLeave={() => setDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragging(false);
                  void handleFiles(e.dataTransfer.files);
                }}
                onClick={() => inputRef.current?.click()}
                className={`cursor-pointer rounded-2xl border-2 border-dashed p-10 text-center transition ${
                  dragging ? "border-indigo-400 bg-indigo-500/10" : "border-slate-700 bg-slate-900/50 hover:border-slate-500"
                }`}
              >
                <div className="text-4xl">📄</div>
                <p className="mt-2 text-lg font-semibold text-slate-100">גררו לכאן צילום של דף כתב יד</p>
                <p className="mt-1 text-sm text-slate-400">או לחצו לבחירת קובץ (JPG / PNG)</p>
                <input
                  ref={inputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => void handleFiles(e.target.files)}
                />
              </div>

              <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
                <h2 className="mb-3 font-semibold text-slate-100">איך זה עובד</h2>
                <ol className="space-y-2 text-sm text-slate-300">
                  <li>
                    <b>1. עיבוד</b> — גווני אפור, בינריזציה מקומית, יישור הטיה, וחלוקה לשורות.
                  </li>
                  <li>
                    <b>2. זיהוי</b> — <b>Mishkefet-v1</b> (CNN+ViT עם ראש CTC, כ-30M פרמטרים) רץ על המחשב בלי אינטרנט.
                    לכל שורה מופעלים 3 תצוגות (TTA) ו-beam search עם מודל שפה של תווים ומילון.
                  </li>
                  <li>
                    <b>3. תיקון</b> — עורכים כל שורה בתיבה שמתחת לתמונה ולוחצים <b>שמור ואמן</b>.
                  </li>
                  <li>
                    <b>4. אימון</b> — ראש ה-CTC מתאמן על השורות שתיקנת (Adam, L2 אל הראש הכללי). סבב נשמר רק אם דיוק
                    בשורות בדיקה לא ירד.
                  </li>
                  <li>
                    <b>5. נתונים</b> — כל שורה שנשמרה נכנסת ל-<code className="text-slate-200">data/dataset/</code> (תמונה
                    + תמלול + manifest) כדי שיהיה נוח לאמן במקום אחר.
                  </li>
                </ol>
              </div>

              <label className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/50 p-3 text-sm text-slate-300">
                <input type="checkbox" checked={useOcr} onChange={(e) => setUseOcr(e.target.checked)} className="size-4" />
                זיהוי אוטומטי עם Mishkefet-v1 (אם כבוי, מתמללים ידנית)
              </label>
            </>
          )}

          {stage === "processing" && (
            <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-8 text-center">
              <div className="mx-auto mb-4 size-10 animate-spin rounded-full border-4 border-slate-700 border-t-indigo-400" />
              <p className="font-medium text-slate-100">{status?.m ?? "מעבד…"}</p>
              <div className="mx-auto mt-3 h-2 w-full max-w-md overflow-hidden rounded-full bg-slate-800">
                <div className="h-full bg-indigo-500 transition-all" style={{ width: `${status?.p ?? 0}%` }} />
              </div>
            </div>
          )}

          {stage === "editing" && (
            <>
              <div className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/60 p-3">
                <button
                  onClick={() => void saveAllAndTrain()}
                  disabled={busy || trainingRunning}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 disabled:opacity-50"
                >
                  ⚡ שמור הכל ואמן את הראש
                </button>
                <button
                  onClick={() => void rerunUnsaved()}
                  disabled={busy}
                  className="rounded-lg bg-slate-800 px-3 py-2 text-sm text-slate-100 hover:bg-slate-700 disabled:opacity-50"
                >
                  ↻ זהה מחדש שורות שלא נערכו
                </button>
                <button onClick={copyText} className="rounded-lg bg-slate-800 px-3 py-2 text-sm text-slate-100 hover:bg-slate-700">
                  העתק טקסט
                </button>
                <button onClick={exportText} className="rounded-lg bg-slate-800 px-3 py-2 text-sm text-slate-100 hover:bg-slate-700">
                  ייצא .txt
                </button>
                <button
                  onClick={() => inputRef.current?.click()}
                  className="rounded-lg bg-slate-800 px-3 py-2 text-sm text-slate-100 hover:bg-slate-700"
                >
                  + דף חדש
                </button>
                <input
                  ref={inputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => void handleFiles(e.target.files)}
                />
                <span className="text-xs text-slate-400">
                  {docName} · {lines.length} שורות · {editedCount} לא נשמרו · זיהוי: {ENGINE_LABEL[ocrEngine]}
                </span>
              </div>

              {status && (
                <div className="rounded-lg border border-indigo-500/30 bg-indigo-500/10 px-3 py-2 text-xs text-indigo-100">
                  {status.m}
                </div>
              )}

              {ocrError && (
                <div className="rounded-lg border border-amber-600/40 bg-amber-500/10 p-3 text-xs text-amber-200">
                  <b>הזיהוי האוטומטי לא זמין</b> — הפירוט: {ocrError}. אפשר להקליד את התמלול ידנית ולשמור; השורות
                  נכנסות ל-data/dataset לאימון.
                </div>
              )}

              <div className="rounded-xl border border-slate-800 bg-slate-900/60">
                <button
                  onClick={() => setShowPage((v) => !v)}
                  className="w-full px-4 py-2 text-start text-sm font-medium text-slate-200"
                >
                  {showPage ? "▾" : "▸"} תצוגת הדף המקורי עם תיבות השורות
                </button>
                {showPage && pageImage && (
                  <div className="relative px-4 pb-4">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={pageImage} alt="הדף הסרוק" className="w-full rounded border border-slate-800 bg-black" />
                    <div className="pointer-events-none absolute inset-4">
                      {lines.map((l, i) => (
                        <div
                          key={l.id ?? i}
                          className="absolute border border-indigo-400/70 bg-indigo-500/10"
                          style={{
                            left: `${(l.box.x / (pageDims[0] || 1)) * 100}%`,
                            top: `${(l.box.y / (pageDims[1] || 1)) * 100}%`,
                            width: `${(l.box.w / (pageDims[0] || 1)) * 100}%`,
                            height: `${(l.box.h / (pageDims[1] || 1)) * 100}%`,
                          }}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {lines.map((l, i) => (
                <LineCard
                  key={l.id ?? i}
                  line={l}
                  number={i + 1}
                  busy={busy}
                  onText={(text) =>
                    setLines((prev) => prev.map((x, j) => (j === i ? { ...x, text, edited: true } : x)))
                  }
                  onSave={(train) => void saveLine(i, train)}
                  onRerun={() => void rerunLine(i)}
                />
              ))}

              <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4">
                <h3 className="mb-2 text-sm font-semibold text-slate-200">טקסט מלא ({fullText.length} תווים)</h3>
                <pre dir="rtl" className="max-h-64 overflow-auto whitespace-pre-wrap text-sm leading-relaxed text-slate-300">
                  {fullText || "—"}
                </pre>
              </div>
            </>
          )}
        </section>

        <aside className="min-w-0 space-y-4">
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
            <h2 className="mb-2 text-sm font-semibold text-slate-100">המודל</h2>
            <dl className="grid grid-cols-2 gap-2 text-xs text-slate-300">
              <div className="col-span-2 rounded-lg bg-slate-950/60 p-2">
                <dt className="text-slate-500">בסיס</dt>
                <dd className="font-semibold text-slate-100">{adapt?.base.name ?? "Mishkefet-v1"}</dd>
                <dd className="text-[11px] text-slate-500">רישיון: {adapt?.base.license ?? "CC-BY-NC-SA-4.0"} (לא מסחרי)</dd>
              </div>
              <div className="rounded-lg bg-slate-950/60 p-2">
                <dt className="text-slate-500">ראש פעיל</dt>
                <dd className="text-lg font-bold text-slate-100">{head?.round ? `#${head.round}` : "בסיס"}</dd>
              </div>
              <div className="rounded-lg bg-slate-950/60 p-2">
                <dt className="text-slate-500">סבבים שהתקבלו</dt>
                <dd className="text-lg font-bold text-slate-100">{accepted}</dd>
              </div>
            </dl>
            {adapt && adapt.rounds.length > 0 && (
              <ul className="mt-3 max-h-48 space-y-1 overflow-auto text-[11px]">
                {adapt.rounds.map((r) => (
                  <li
                    key={`${r.round}-${r.at}`}
                    className={`rounded px-2 py-1 ${r.accepted ? "bg-emerald-500/10 text-emerald-200" : "bg-rose-500/10 text-rose-200"}`}
                  >
                    סבב {r.round} · {r.accepted ? "התקבל" : "נדחה"} · {r.trainSamples} שורות · {r.reason}
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
            <h2 className="mb-2 text-sm font-semibold text-slate-100">תיקיית הנתונים</h2>
            <p className="text-xs text-slate-400">
              <code className="text-slate-200">{adapt?.dataset.dir ?? "data/dataset"}/</code> — דפים, שורות מתומללות
              (תמונה + .txt), manifest.tsv ו-lines.jsonl.
            </p>
            <dl className="mt-2 grid grid-cols-3 gap-2 text-center text-xs">
              <div className="rounded-lg bg-slate-950/60 p-2">
                <dt className="text-slate-500">דפים</dt>
                <dd className="font-bold text-slate-100">{adapt?.dataset.pages ?? 0}</dd>
              </div>
              <div className="rounded-lg bg-slate-950/60 p-2">
                <dt className="text-slate-500">שורות שנשמרו</dt>
                <dd className="font-bold text-slate-100">{adapt?.dataset.lines ?? 0}</dd>
              </div>
              <div className="rounded-lg bg-slate-950/60 p-2">
                <dt className="text-slate-500">לאימון</dt>
                <dd className="font-bold text-slate-100">{adapt?.dataset.trainable ?? 0}</dd>
              </div>
            </dl>
            <a
              href="/api/dataset/zip"
              className="mt-3 block rounded-lg bg-slate-800 px-3 py-2 text-center text-sm text-slate-100 hover:bg-slate-700"
            >
              ⬇ הורד את כל data/ כ-ZIP (לאימון במקום אחר)
            </a>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-100">דפים שנסרקו</h2>
              <button onClick={() => void refreshDocs()} className="text-xs text-slate-400 hover:text-slate-200">
                רענן
              </button>
            </div>
            <ul className="space-y-1">
              {docs.length === 0 && <li className="text-xs text-slate-500">אין מסמכים עדיין</li>}
              {docs.map((d) => (
                <li
                  key={d.id}
                  className={`flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-xs ${
                    d.id === docId ? "bg-indigo-500/15 text-indigo-200" : "text-slate-300 hover:bg-slate-800/60"
                  }`}
                >
                  <button onClick={() => void loadDoc(d.id)} className="flex-1 truncate text-start">
                    #{d.id} {d.name} <span className="text-slate-500">({d.lineCount} שורות)</span>
                  </button>
                  <button onClick={() => void deleteDoc(d.id)} className="text-rose-400 hover:text-rose-300" title="מחק">
                    ✕
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </main>

      {toast && (
        <div className="fixed bottom-4 left-1/2 z-50 max-w-[90vw] -translate-x-1/2 rounded-xl border border-indigo-500/40 bg-slate-900 px-4 py-2 text-sm text-slate-100 shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
}
