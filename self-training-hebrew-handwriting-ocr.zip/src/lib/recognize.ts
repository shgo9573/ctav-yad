import type { RecognizeResult } from "./apiTypes";

const CHUNK = 6;

/** שולח תמונות שורה (JPEG base64) לשרת Mishkefet-v1, בקבוצות קטנות כדי להציג התקדמות */
export async function recognizeOnServer(
  crops: string[],
  onProgress?: (done: number, total: number) => void,
): Promise<RecognizeResult[]> {
  const out: RecognizeResult[] = [];
  for (let i = 0; i < crops.length; i += CHUNK) {
    const chunk = crops.slice(i, i + CHUNK);
    const res = await fetch("/api/recognize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lines: chunk.map((imageBase64) => ({ imageBase64 })) }),
    });
    const data = (await res.json().catch(() => ({}))) as { results?: RecognizeResult[]; error?: string };
    if (!res.ok || !data.results) throw new Error(data.error || `Mishkefet: HTTP ${res.status}`);
    out.push(...data.results);
    onProgress?.(out.length, crops.length);
  }
  return out;
}
