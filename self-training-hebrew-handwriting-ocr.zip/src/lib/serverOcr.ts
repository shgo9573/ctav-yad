import path from "node:path";
import { createWorker, PSM } from "tesseract.js";
import { flattenTessBlocks, type TessLine } from "./ocrParse";

type TessWorker = Awaited<ReturnType<typeof createWorker>>;

/** מצב גלובלי: worker יחיד שנטען פעם אחת ומשותף לכל הבקשות (נשמר גם בפיתוח עם hot reload) */
type Holder = { worker?: Promise<TessWorker>; queue: Promise<unknown> };
const g = globalThis as typeof globalThis & { __hebOcrHolder?: Holder };
const holder: Holder = g.__hebOcrHolder ?? (g.__hebOcrHolder = { queue: Promise.resolve() });

function getWorker(): Promise<TessWorker> {
  if (!holder.worker) {
    holder.worker = (async () => {
      const worker = await createWorker("heb", 1, {
        langPath: path.join(process.cwd(), "public", "tessdata"),
        gzip: false,
        logger: () => {},
      });
      await worker.setParameters({ tessedit_pageseg_mode: PSM.SINGLE_COLUMN });
      return worker;
    })().catch((err: unknown) => {
      holder.worker = undefined;
      throw err;
    });
  }
  return holder.worker;
}

/** זיהוי עמוד שלם בשרת. הבקשות מתורגות אחת-אחרי-השנייה כדי לא לערבב זיכרון של ה-worker */
export function recognizePageOnServer(jpeg: Buffer): Promise<TessLine[]> {
  const job = holder.queue.then(async () => {
    const worker = await getWorker();
    const res = await worker.recognize(jpeg, {}, { text: true, blocks: true });
    return flattenTessBlocks(res.data.blocks);
  });
  holder.queue = job.catch(() => undefined);
  return job;
}
