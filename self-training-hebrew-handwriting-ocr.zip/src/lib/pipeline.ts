import {
  binarize,
  cropImageBase64,
  detectLineBoxes,
  estimateSkew,
  fullImageBase64,
  grayFromCanvas,
  loadImageFromFile,
  preparePage,
  rotateCanvas,
  type Box,
} from "./vision";
import { browserOcr, describeError, matchTessText, serverOcr, type OcrEngine } from "./ocr";
import type { TessLine } from "./ocrParse";
import { recognizeOnServer } from "./recognize";

export type PipelineLine = {
  idx: number;
  box: Box;
  imageBase64: string;
  /** הפלט הגולמי של המודל לשורה */
  raw: string;
  confidence: number;
};

export type ProcessResult = {
  width: number;
  height: number;
  imageBase64: string;
  lines: PipelineLine[];
  ocrEngine: OcrEngine;
  ocrError?: string;
  skewAngle: number;
};

export type ProcessOptions = {
  useOcr: boolean;
  maxLines?: number;
  onStatus: (message: string, progress: number) => void;
};

/**
 * צינור עיבוד דף: תמונה → יישור הטיה → שורות → זיהוי.
 * הזיהוי הראשי: Mishkefet-v1 בשרת (ONNX מקומי). גיבוי: tesseract heb (שרת, ואז דפדפן).
 */
export async function processPage(file: File, opts: ProcessOptions): Promise<ProcessResult> {
  const { onStatus } = opts;
  onStatus("טוען תמונה…", 5);
  const img = await loadImageFromFile(file);
  let page = preparePage(img, 1500);
  let width = page.canvas.width;
  let height = page.canvas.height;

  onStatus("מנתח דיו ומיישר הטיה…", 12);
  let g = grayFromCanvas(page.canvas);
  let ink = binarize(g.gray, g.w, g.h);
  const angle = estimateSkew(ink, g.w, g.h);
  if (Math.abs(angle) >= 0.5) {
    page = { canvas: rotateCanvas(page.canvas, angle), w: 0, h: 0 };
    width = page.canvas.width;
    height = page.canvas.height;
    g = grayFromCanvas(page.canvas);
    ink = binarize(g.gray, g.w, g.h);
  }

  onStatus("מחפש שורות טקסט…", 20);
  const boxes = detectLineBoxes(ink, width, height).slice(0, opts.maxLines ?? 120);
  const crops = boxes.map((box) => cropImageBase64(page.canvas, box));

  let texts: string[] | null = null;
  let confidences: number[] = [];
  let ocrEngine: OcrEngine = "none";
  const ocrErrors: string[] = [];

  if (opts.useOcr && boxes.length) {
    onStatus("מזהה כתב יד עם Mishkefet-v1…", 25);
    try {
      const res = await recognizeOnServer(crops, (done, total) =>
        onStatus(`Mishkefet-v1: ${done} מתוך ${total} שורות`, 25 + Math.round((done / total) * 65)),
      );
      texts = res.map((r) => r.text);
      confidences = res.map((r) => r.confidence);
      ocrEngine = "mishkefet";
    } catch (err) {
      ocrErrors.push(`Mishkefet: ${describeError(err)}`);
    }
  }

  if (opts.useOcr && !texts && boxes.length) {
    onStatus("גיבוי: tesseract עברי בשרת…", 30);
    let tess: TessLine[] = [];
    try {
      tess = await serverOcr(page.canvas);
      ocrEngine = "server";
    } catch (err) {
      ocrErrors.push(`tesseract שרת: ${describeError(err)}`);
      try {
        tess = await browserOcr(page.canvas, (s, p) =>
          onStatus(`גיבוי בדפדפן: ${s}`, 40 + Math.round(Math.max(0, Math.min(1, p)) * 20)),
        );
        ocrEngine = "browser";
      } catch (err2) {
        ocrErrors.push(`tesseract דפדפן: ${describeError(err2)}`);
      }
    }
    if (ocrEngine !== "none") {
      texts = matchTessText(boxes, tess).map((t) => t ?? "");
      confidences = texts.map(() => 0);
    }
  }

  const ocrError = opts.useOcr && !texts && boxes.length ? ocrErrors.join(" | ") : undefined;
  const out: PipelineLine[] = boxes.map((box, i) => ({
    idx: i,
    box,
    imageBase64: crops[i],
    raw: texts?.[i] ?? "",
    confidence: confidences[i] ?? 0,
  }));
  onStatus("מסיים…", 95);
  await new Promise((resolve) => window.setTimeout(resolve, 0));

  return {
    width,
    height,
    imageBase64: fullImageBase64(page.canvas),
    lines: out,
    ocrEngine,
    ocrError,
    skewAngle: angle,
  };
}
