import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { and, asc, eq, isNotNull } from "drizzle-orm";
import { db } from "@/db";
import { documents, lines } from "@/db/schema";
import { isHeldOutId } from "./split";

/**
 * תיקיית הנתונים: כל מה שנאסף בזמן העבודה נכנס ל-data/ כדי שיהיה נוח להעביר ולאמן במקום אחר.
 *   data/dataset/pages/           סריקות מלאות של דפים (JPEG)
 *   data/dataset/lines/           שורות מתוקנות: <doc>_<idx>_<line>.jpg + .txt (התמלול)
 *   data/dataset/manifest.tsv     טבלה: image, text, split(train/val), מטא-דאטה
 *   data/dataset/lines.jsonl      אותו מידע בפורמט JSON Lines
 *   data/heads/                   גרסאות ראש CTC שאומנו (head-r*.bin, rounds.json, current.json)
 */
export const DATA_DIR = path.join(process.cwd(), "data");
export const DATASET_DIR = path.join(DATA_DIR, "dataset");
const PAGES_DIR = path.join(DATASET_DIR, "pages");
const LINES_DIR = path.join(DATASET_DIR, "lines");

const README = `# מאגר נתוני כתב יד עברי (Mishkefet-v1)

נוצר אוטומטית על ידי האפליקציה. כל שורה שתיקנת ושמרת מופיעה כאן.

- pages/      סריקות מלאות של הדפים (JPEG)
- lines/      תמונת כל שורה (.jpg) וקובץ תמלול תואם (.txt, UTF-8)
- manifest.tsv  טבלה מופרדת בטאבים עם כותרת. העמודות:
                image (נתיב יחסי לתיקיית dataset), text (התמלול הנכון),
                split (train / val), doc_id, doc_name, line_index, line_id,
                box_x, box_y, box_w, box_h, confidence, model_raw, updated_at
- lines.jsonl   אותו מידע בפורמט JSON Lines
- ../heads/     ראשי CTC שאומנו על הנתונים (head-r<N>.bin בפורמט MKH1,
                rounds.json עם תוצאות כל סבב, current.json עם הגרסה הפעילה)

החלוקה split נקבעת לפי hash קבוע של מזהה השורה: כ-1/8 מהשורות הן val
(בדיקה) ואינן נכנסות לאימון. ניתן להשתמש בה כמו שהיא, או לחלק מחדש.
`;

function ensureDirs() {
  fs.mkdirSync(PAGES_DIR, { recursive: true });
  fs.mkdirSync(LINES_DIR, { recursive: true });
}

const pad = (n: number, w: number) => String(n).padStart(w, "0");

function slug(name: string): string {
  const base = name.replace(/\.[^.]+$/, "");
  return base.replace(/[^\p{L}\p{N}_-]+/gu, "_").slice(0, 60) || "page";
}

const clean = (s: string | null | undefined) => (s ?? "").replace(/[\t\r\n]+/g, " ").trim();

/** שמירת סריקת דף מלאה לתיקיית הנתונים */
export function savePageImage(docId: number, name: string, jpegBase64: string): string {
  ensureDirs();
  const file = `${pad(docId, 5)}_${slug(name)}.jpg`;
  fs.writeFileSync(path.join(PAGES_DIR, file), Buffer.from(jpegBase64, "base64"));
  return `pages/${file}`;
}

/** מסנכרן את תיקיית הנתונים עם מסד הנתונים: שורות שנשמרו (status=edited) עם תמלול */
export async function syncDataset(): Promise<{ lines: number; pages: number }> {
  ensureDirs();
  const rows = await db
    .select({
      lineId: lines.id,
      docId: lines.documentId,
      docName: documents.name,
      idx: lines.idx,
      text: lines.text,
      rawText: lines.rawText,
      confidence: lines.confidence,
      x: lines.x,
      y: lines.y,
      w: lines.w,
      h: lines.h,
      image: lines.imageBase64,
      updatedAt: lines.updatedAt,
    })
    .from(lines)
    .innerJoin(documents, eq(lines.documentId, documents.id))
    .where(and(eq(lines.status, "edited"), isNotNull(lines.imageBase64)))
    .orderBy(asc(documents.id), asc(lines.idx));

  const keep = new Set<string>();
  const manifest: string[] = [
    [
      "image",
      "text",
      "split",
      "doc_id",
      "doc_name",
      "line_index",
      "line_id",
      "box_x",
      "box_y",
      "box_w",
      "box_h",
      "confidence",
      "model_raw",
      "updated_at",
    ].join("\t"),
  ];
  const jsonl: string[] = [];

  for (const r of rows) {
    const text = (r.text ?? "").replace(/\s+/g, " ").trim();
    if (!text || !r.image) continue;
    const base = `${pad(r.docId, 5)}_${pad(r.idx, 3)}_${r.lineId}`;
    keep.add(`${base}.jpg`);
    keep.add(`${base}.txt`);
    const imgPath = path.join(LINES_DIR, `${base}.jpg`);
    if (!fs.existsSync(imgPath)) fs.writeFileSync(imgPath, Buffer.from(r.image, "base64"));
    fs.writeFileSync(path.join(LINES_DIR, `${base}.txt`), `${text}\n`, "utf8");

    const image = `lines/${base}.jpg`;
    const split = isHeldOutId(r.lineId) ? "val" : "train";
    const updatedAt = r.updatedAt.toISOString();
    manifest.push(
      [
        image,
        text,
        split,
        r.docId,
        clean(r.docName),
        r.idx,
        r.lineId,
        r.x,
        r.y,
        r.w,
        r.h,
        Number(r.confidence).toFixed(4),
        clean(r.rawText),
        updatedAt,
      ].join("\t"),
    );
    jsonl.push(
      JSON.stringify({
        image,
        text,
        split,
        doc_id: r.docId,
        doc_name: r.docName,
        line_index: r.idx,
        line_id: r.lineId,
        box: { x: r.x, y: r.y, w: r.w, h: r.h },
        confidence: Number(Number(r.confidence).toFixed(4)),
        model_raw: clean(r.rawText),
        updated_at: updatedAt,
      }),
    );
  }

  for (const f of fs.readdirSync(LINES_DIR)) {
    if (!keep.has(f)) fs.rmSync(path.join(LINES_DIR, f), { force: true });
  }
  fs.writeFileSync(path.join(DATASET_DIR, "manifest.tsv"), `${manifest.join("\n")}\n`, "utf8");
  fs.writeFileSync(path.join(DATASET_DIR, "lines.jsonl"), jsonl.length ? `${jsonl.join("\n")}\n` : "", "utf8");
  fs.writeFileSync(path.join(DATASET_DIR, "README.md"), README, "utf8");
  const pages = fs.readdirSync(PAGES_DIR).filter((f) => f.endsWith(".jpg")).length;
  return { lines: jsonl.length, pages };
}

/* ------------------------------ ZIP (ללא תלויות) ------------------------------ */

function walk(dir: string, rel: string, out: { abs: string; rel: string }[]) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, e.name);
    const r = path.posix.join(rel, e.name);
    if (e.isDirectory()) walk(abs, r, out);
    else if (e.isFile()) out.push({ abs, rel: r });
  }
}

/** ארכיון ZIP של כל תיקיית data/ (לשמירה/העברה למחשב אימון) */
export function buildDataZip(): Buffer {
  const files: { abs: string; rel: string }[] = [];
  if (fs.existsSync(DATA_DIR)) walk(DATA_DIR, "data", files);
  const parts: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;
  for (const f of files) {
    const raw = fs.readFileSync(f.abs);
    const comp = zlib.deflateRawSync(raw);
    const crc = zlib.crc32(raw);
    const name = Buffer.from(f.rel, "utf8");

    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0);
    lh.writeUInt16LE(20, 4);
    lh.writeUInt16LE(0x0800, 6);
    lh.writeUInt16LE(8, 8);
    lh.writeUInt16LE(0, 10);
    lh.writeUInt16LE(0x21, 12);
    lh.writeUInt32LE(crc >>> 0, 14);
    lh.writeUInt32LE(comp.length, 18);
    lh.writeUInt32LE(raw.length, 22);
    lh.writeUInt16LE(name.length, 26);
    lh.writeUInt16LE(0, 28);
    parts.push(lh, name, comp);

    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0);
    ch.writeUInt16LE(20, 4);
    ch.writeUInt16LE(20, 6);
    ch.writeUInt16LE(0x0800, 8);
    ch.writeUInt16LE(8, 10);
    ch.writeUInt16LE(0, 12);
    ch.writeUInt16LE(0x21, 14);
    ch.writeUInt32LE(crc >>> 0, 16);
    ch.writeUInt32LE(comp.length, 20);
    ch.writeUInt32LE(raw.length, 24);
    ch.writeUInt16LE(name.length, 28);
    ch.writeUInt16LE(0, 30);
    ch.writeUInt16LE(0, 32);
    ch.writeUInt16LE(0, 34);
    ch.writeUInt16LE(0, 36);
    ch.writeUInt32LE(0, 38);
    ch.writeUInt32LE(offset, 42);
    central.push(ch, name);
    offset += lh.length + name.length + comp.length;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(cd.length, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...parts, cd, end]);
}
