/** חלוקה דטרמיניסטית לאימון/בדיקה: hash(id) % 8 == 0 → בדיקה (FNV-1a 32 על ה-UTF-8 של ה-id) */

export function fnv1a32(s: string): number {
  let h = 0x811c9dc5;
  for (const b of Buffer.from(s, "utf8")) {
    h ^= b;
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

export function isHeldOutId(id: number): boolean {
  return fnv1a32(String(id)) % 8 === 0;
}
