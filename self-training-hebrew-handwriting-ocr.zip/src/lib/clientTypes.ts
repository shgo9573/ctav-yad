import type { Box } from "./vision";

export type LineState = {
  id?: number;
  idx: number;
  imageBase64: string;
  box: Box;
  /** התמלול כפי שמוצג ונערך */
  text: string;
  /** הפלט המקורי של המודל (לא משתנה), נשמר לצורך השוואה */
  raw: string;
  confidence: number;
  edited: boolean;
  savedAt?: string;
};
