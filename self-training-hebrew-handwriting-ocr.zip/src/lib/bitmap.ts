/**
 * מפת גליף: רשת 24x24 של פיקסלי דיו (0/1), נארזת ל-72 בייטים ומקודדת base64.
 * פורמט קומפקטי שנשמר ב-DB וב-snapshot של המודל ועובד בדפדפן ובשרת ללא תלות.
 */

export const BM = 24;
export const BM_CELLS = BM * BM;
const BM_BYTES = BM_CELLS / 8; // 72
const INNER = 20; // גודל פנימי לפני ריפוד

const B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

export function bytesToBase64(bytes: Uint8Array): string {
  let out = "";
  let i = 0;
  for (; i + 2 < bytes.length; i += 3) {
    const n = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2];
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + B64[(n >> 6) & 63] + B64[n & 63];
  }
  if (i + 1 === bytes.length) {
    const n = bytes[i] << 16;
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + "==";
  } else if (i + 2 === bytes.length) {
    const n = (bytes[i] << 16) | (bytes[i + 1] << 8);
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + B64[(n >> 6) & 63] + "=";
  }
  return out;
}

export function base64ToBytes(s: string): Uint8Array {
  const clean = s.replace(/[^A-Za-z0-9+/]/g, "");
  const len = clean.length;
  const out = new Uint8Array(Math.floor((len * 6) / 8));
  let o = 0;
  let buf = 0;
  let bits = 0;
  for (let i = 0; i < len; i++) {
    const v = B64.indexOf(clean[i]);
    if (v < 0) continue;
    buf = (buf << 6) | v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out[o++] = (buf >> bits) & 0xff;
    }
  }
  return out;
}

export function packBitmap(bits: Uint8Array): string {
  const bytes = new Uint8Array(BM_BYTES);
  for (let i = 0; i < BM_CELLS; i++) {
    if (bits[i]) bytes[i >> 3] |= 1 << (i & 7);
  }
  return bytesToBase64(bytes);
}

export function unpackBitmap(b64: string): Uint8Array {
  const bytes = base64ToBytes(b64);
  const bits = new Uint8Array(BM_CELLS);
  for (let i = 0; i < BM_CELLS && i < bytes.length * 8; i++) {
    bits[i] = (bytes[i >> 3] >> (i & 7)) & 1;
  }
  return bits;
}

const BM_WORDS = BM_CELLS / 32; // 18

const POPCOUNT = (() => {
  const table = new Uint8Array(256);
  for (let i = 0; i < 256; i++) {
    let c = 0;
    let v = i;
    while (v) {
      c += v & 1;
      v >>= 1;
    }
    table[i] = c;
  }
  return table;
})();

/** אריזת 576 ביטים ל-18 מילים של 32 ביט (להשוואות מהירות) */
export function packBitsToWords(bits: Uint8Array): Uint32Array {
  const words = new Uint32Array(BM_WORDS);
  for (let i = 0; i < BM_CELLS; i++) {
    if (bits[i]) words[i >>> 5] |= 1 << (i & 31);
  }
  return words;
}

export function bitsToWords(bitmapB64: string): Uint32Array {
  return packBitsToWords(unpackBitmap(bitmapB64));
}

/** מרחק חמינג בין שתי מפות גליף (במילים) */
export function hammingWords(a: Uint32Array, b: Uint32Array): number {
  let dist = 0;
  for (let i = 0; i < BM_WORDS; i++) {
    dist += POPCOUNT[(a[i] ^ b[i]) & 0xff];
    dist += POPCOUNT[((a[i] ^ b[i]) >>> 8) & 0xff];
    dist += POPCOUNT[((a[i] ^ b[i]) >>> 16) & 0xff];
    dist += POPCOUNT[((a[i] ^ b[i]) >>> 24) & 0xff];
  }
  return dist;
}

export function similarityWords(a: Uint32Array, b: Uint32Array): number {
  return 1 - hammingWords(a, b) / BM_CELLS;
}

/** דמיון חמינג (0..1) בין שתי מפות גליף */
export function bitmapSimilarity(a: Uint8Array, b: Uint8Array): number {
  let same = 0;
  for (let i = 0; i < BM_CELLS; i++) if (a[i] === b[i]) same++;
  return same / BM_CELLS;
}

export function bitmapOverlap(a: Uint8Array, b: Uint8Array): number {
  let inter = 0;
  let union = 0;
  for (let i = 0; i < BM_CELLS; i++) {
    if (a[i] || b[i]) union++;
    if (a[i] && b[i]) inter++;
  }
  return union === 0 ? 0 : inter / union;
}

/** סנכרון גודל: חיתוך הדיו, שמירה על יחס גובה-רוחב והתאמה ל-24x24 ממורכז */
export function normalizeInk(
  ink: Uint8Array,
  w: number,
  h: number,
): { bitmap: Uint8Array; aspect: number; inkRatio: number } {
  let x0 = w;
  let y0 = h;
  let x1 = -1;
  let y1 = -1;
  let total = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (ink[y * w + x]) {
        total++;
        if (x < x0) x0 = x;
        if (x > x1) x1 = x;
        if (y < y0) y0 = y;
        if (y > y1) y1 = y;
      }
    }
  }
  const bitmap = new Uint8Array(BM_CELLS);
  if (x1 < 0 || total === 0) return { bitmap, aspect: 1, inkRatio: 0 };
  const bw = x1 - x0 + 1;
  const bh = y1 - y0 + 1;
  const scale = INNER / Math.max(bw, bh);
  const dw = Math.max(1, Math.min(BM - 1, Math.round(bw * scale)));
  const dh = Math.max(1, Math.min(BM - 1, Math.round(bh * scale)));
  const ox = Math.floor((BM - dw) / 2);
  const oy = Math.floor((BM - dh) / 2);
  let drawn = 0;
  for (let ty = 0; ty < dh; ty++) {
    const sy = y0 + Math.min(bh - 1, Math.floor(((ty + 0.5) * bh) / dh));
    for (let tx = 0; tx < dw; tx++) {
      const sx = x0 + Math.min(bw - 1, Math.floor(((tx + 0.5) * bw) / dw));
      if (ink[sy * w + sx]) {
        bitmap[(oy + ty) * BM + (ox + tx)] = 1;
        drawn++;
      }
    }
  }
  const aspect = Math.max(0.15, Math.min(6, bw / bh));
  return { bitmap, aspect, inkRatio: drawn / BM_CELLS };
}
