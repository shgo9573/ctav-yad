import { normalizeInk, packBitmap } from "./bitmap";

export type Box = { x: number; y: number; w: number; h: number };
export type GlyphSeg = {
  box: Box;
  spaceBefore: boolean;
  bitmap: string;
  aspect: number;
  inkRatio: number;
  noise: boolean;
};
export type SegmentedLine = { box: Box; imageBase64: string; glyphs: GlyphSeg[] };

/* ------------------------------ טעינת תמונה ------------------------------ */

export function loadImageFromFile(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("קריאת הקובץ נכשלה"));
    reader.onload = () => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("טעינת התמונה נכשלה"));
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

function makeCanvas(w: number, h: number): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D } {
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(w));
  canvas.height = Math.max(1, Math.round(h));
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas לא זמין בדפדפן");
  return { canvas, ctx };
}

export function preparePage(img: HTMLImageElement, maxDim = 1500): { canvas: HTMLCanvasElement; w: number; h: number } {
  const scale = Math.min(1, maxDim / Math.max(img.naturalWidth, img.naturalHeight));
  const w = Math.max(64, Math.round(img.naturalWidth * scale));
  const h = Math.max(64, Math.round(img.naturalHeight * scale));
  const { canvas, ctx } = makeCanvas(w, h);
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(img, 0, 0, w, h);
  return { canvas, w, h };
}

/* --------------------------------- גווני אפור --------------------------------- */

export function grayFromCanvas(canvas: HTMLCanvasElement): { gray: Uint8Array; w: number; h: number } {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas לא זמין");
  const { width: w, height: h } = canvas;
  const data = ctx.getImageData(0, 0, w, h).data;
  const gray = new Uint8Array(w * h);
  for (let i = 0, p = 0; i < gray.length; i++, p += 4) {
    gray[i] = (data[p] * 299 + data[p + 1] * 587 + data[p + 2] * 114) / 1000;
  }
  return { gray, w, h };
}

/* ------------------------------- בינריזציה ------------------------------- */

function otsuThreshold(gray: Uint8Array): number {
  const hist = new Array<number>(256).fill(0);
  for (let i = 0; i < gray.length; i++) hist[gray[i]]++;
  const total = gray.length;
  let sum = 0;
  for (let t = 0; t < 256; t++) sum += t * hist[t];
  let sumB = 0;
  let wB = 0;
  let best = 0;
  let thr = 128;
  for (let t = 0; t < 256; t++) {
    wB += hist[t];
    if (!wB) continue;
    const wF = total - wB;
    if (!wF) break;
    sumB += t * hist[t];
    const mB = sumB / wB;
    const mF = (sum - sumB) / wF;
    const between = wB * wF * (mB - mF) * (mB - mF);
    if (between > best) {
      best = between;
      thr = t;
    }
  }
  return thr;
}

/** Sauvola מקומי עם נפילה חזרה ל-Otsu הגלובלי */
export function binarize(gray: Uint8Array, w: number, h: number): Uint8Array {
  const n = w * h;
  const integral = new Float64Array((w + 1) * (h + 1));
  const integralSq = new Float64Array((w + 1) * (h + 1));
  for (let y = 0; y < h; y++) {
    let rowSum = 0;
    let rowSq = 0;
    for (let x = 0; x < w; x++) {
      const v = gray[y * w + x];
      rowSum += v;
      rowSq += v * v;
      const idx = (y + 1) * (w + 1) + (x + 1);
      integral[idx] = integral[(y) * (w + 1) + (x + 1)] + rowSum;
      integralSq[idx] = integralSq[(y) * (w + 1) + (x + 1)] + rowSq;
    }
  }
  const R = 128;
  const k = 0.22;
  const win = Math.max(11, Math.round(Math.min(w, h) / 28) | 1);
  const half = Math.floor(win / 2);
  const ink = new Uint8Array(n);
  let count = 0;
  for (let y = 0; y < h; y++) {
    const y0 = Math.max(0, y - half);
    const y1 = Math.min(h - 1, y + half);
    for (let x = 0; x < w; x++) {
      const x0 = Math.max(0, x - half);
      const x1 = Math.min(w - 1, x + half);
      const area = (y1 - y0 + 1) * (x1 - x0 + 1);
      const A = (y1 + 1) * (w + 1) + (x1 + 1);
      const B = y0 * (w + 1) + (x1 + 1);
      const C = (y1 + 1) * (w + 1) + x0;
      const D = y0 * (w + 1) + x0;
      const s = integral[A] - integral[B] - integral[C] + integral[D];
      const sq = integralSq[A] - integralSq[B] - integralSq[C] + integralSq[D];
      const mean = s / area;
      const variance = Math.max(0, sq / area - mean * mean);
      const std = Math.sqrt(variance);
      const t = mean * (1 + k * (std / R - 1));
      if (gray[y * w + x] < t) {
        ink[y * w + x] = 1;
        count++;
      }
    }
  }
  const ratio = count / n;
  if (ratio < 0.02 || ratio > 0.42) {
    const thr = otsuThreshold(gray);
    for (let i = 0; i < n; i++) ink[i] = gray[i] < thr ? 1 : 0;
  }
  return ink;
}

/* ------------------------------- יישור הטיה ------------------------------- */

export function estimateSkew(ink: Uint8Array, w: number, h: number): number {
  const pts: number[] = [];
  const step = Math.max(1, Math.floor(Math.sqrt((w * h) / 120000)));
  for (let y = 0; y < h; y += step) {
    for (let x = 0; x < w; x += step) {
      if (ink[y * w + x]) {
        pts.push(x, y);
      }
    }
  }
  const count = pts.length / 2;
  if (count < 200) return 0;
  const rows = new Float64Array(h + 64);
  let bestScore = -1;
  let bestAngle = 0;
  const cx = w / 2;
  for (let a = -6; a <= 6; a += 0.5) {
    rows.fill(0);
    const tan = Math.tan((a * Math.PI) / 180);
    for (let i = 0; i < pts.length; i += 2) {
      const r = Math.round(pts[i + 1] + (pts[i] - cx) * tan);
      if (r >= 0 && r < rows.length) rows[r]++;
    }
    let mean = 0;
    for (let i = 0; i < rows.length; i++) mean += rows[i];
    mean /= rows.length;
    let variance = 0;
    for (let i = 0; i < rows.length; i++) {
      const d = rows[i] - mean;
      variance += d * d;
    }
    if (variance > bestScore) {
      bestScore = variance;
      bestAngle = a;
    }
  }
  return Math.abs(bestAngle) >= 0.4 ? bestAngle : 0;
}

export function rotateCanvas(src: HTMLCanvasElement, deg: number): HTMLCanvasElement {
  const rad = (deg * Math.PI) / 180;
  const w = src.width;
  const h = src.height;
  const nw = Math.round(Math.abs(w * Math.cos(rad)) + Math.abs(h * Math.sin(rad)));
  const nh = Math.round(Math.abs(w * Math.sin(rad)) + Math.abs(h * Math.cos(rad)));
  const { canvas, ctx } = makeCanvas(nw, nh);
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, nw, nh);
  ctx.translate(nw / 2, nh / 2);
  ctx.rotate(rad);
  ctx.drawImage(src, -w / 2, -h / 2);
  return canvas;
}

/* ----------------------------- פיצול לשורות ----------------------------- */

export function detectLineBoxes(ink: Uint8Array, w: number, h: number): Box[] {
  const rowInk = new Float64Array(h);
  for (let y = 0; y < h; y++) {
    let s = 0;
    const base = y * w;
    for (let x = 0; x < w; x++) if (ink[base + x]) s++;
    rowInk[y] = s;
  }
  // החלקת פרופיל (חלון נע) כדי ששורות לא יתפצלו בין שורות דיו
  const smooth = new Float64Array(h);
  const rad = 2;
  let winSum = 0;
  for (let y = 0; y < h + rad; y++) {
    const addY = y;
    if (addY < h) winSum += rowInk[addY];
    const takeY = y - 2 * rad - 1;
    if (takeY >= 0) winSum -= rowInk[takeY];
    const center = y - rad;
    if (center >= 0 && center < h) smooth[center] = winSum / (2 * rad + 1);
  }
  let maxRow = 0;
  for (let y = 0; y < h; y++) if (smooth[y] > maxRow) maxRow = smooth[y];
  if (maxRow <= 0) return [];
  const thr = Math.max(1.5, maxRow * 0.15);
  const lowThr = Math.max(1, maxRow * 0.04);

  const runs: { y0: number; y1: number }[] = [];
  let start = -1;
  for (let y = 0; y < h; y++) {
    if (smooth[y] >= thr) {
      if (start < 0) start = y;
    } else if (start >= 0) {
      runs.push({ y0: start, y1: y - 1 });
      start = -1;
    }
  }
  if (start >= 0) runs.push({ y0: start, y1: h - 1 });

  // איחוד רצועות קרובות (גפים/סגלים/שורות דיו חלשות בתוך שורה)
  const merged: { y0: number; y1: number }[] = [];
  for (const r of runs) {
    const prev = merged[merged.length - 1];
    if (prev) {
      const gap = r.y0 - prev.y1 - 1;
      let valley = Infinity;
      for (let y = prev.y1 + 1; y < r.y0; y++) {
        if (smooth[y] < valley) valley = smooth[y];
      }
      if (valley === Infinity) valley = 0;
      if (gap <= 5 || (gap <= 14 && valley > 0.18 * Math.min(smooth[prev.y0], smooth[r.y0]))) {
        prev.y1 = r.y1;
        continue;
      }
    }
    merged.push({ ...r });
  }
  // ספיחת שוליים חלשים מעל/מתחת (גפים וסגלים)
  for (const r of merged) {
    while (r.y0 - 1 >= 0 && smooth[r.y0 - 1] > lowThr) r.y0--;
    while (r.y1 + 1 < h && smooth[r.y1 + 1] > lowThr) r.y1++;
  }
  // פיצול רצועות גבוהות מדי (שתי שורות שנדבקו)
  const heights = merged.map((r) => r.y1 - r.y0 + 1).sort((a, b) => a - b);
  const medH = heights[Math.floor(heights.length / 2)] || 20;
  const split = (r: { y0: number; y1: number }): { y0: number; y1: number }[] => {
    const height = r.y1 - r.y0 + 1;
    if (height < medH * 2.2 || height < 24) return [r];
    let minV = Infinity;
    let minY = Math.floor((r.y0 + r.y1) / 2);
    for (let y = r.y0 + Math.floor(height * 0.32); y <= r.y1 - Math.floor(height * 0.32); y++) {
      if (rowInk[y] < minV) {
        minV = rowInk[y];
        minY = y;
      }
    }
    return [...split({ y0: r.y0, y1: minY - 1 }), ...split({ y0: minY + 1, y1: r.y1 })];
  };
  const bands = merged.flatMap(split).filter((r) => r.y1 - r.y0 + 1 >= 6);

  // חישוב גבולות אופקיים
  const boxes: Box[] = [];
  for (const b of bands) {
    const colInk = new Float64Array(w);
    let total = 0;
    for (let y = b.y0; y <= b.y1; y++) {
      const base = y * w;
      for (let x = 0; x < w; x++)
        if (ink[base + x]) {
          colInk[x]++;
          total++;
        }
    }
    if (total < 25) continue;
    let x0 = -1;
    let x1 = -1;
    for (let x = 0; x < w; x++)
      if (colInk[x] > 0) {
        if (x0 < 0) x0 = x;
        x1 = x;
      }
    if (x0 < 0 || x1 - x0 < 6) continue;
    boxes.push({
      x: Math.max(0, x0 - 3),
      y: Math.max(0, b.y0 - 2),
      w: Math.min(w, x1 + 4) - Math.max(0, x0 - 3),
      h: Math.min(h, b.y1 + 3) - Math.max(0, b.y0 - 2),
    });
  }
  return boxes;
}

/* ---------------------------- חיתוך גליפים ---------------------------- */

type Comp = { x0: number; y0: number; x1: number; y1: number; area: number };

function connectedComponents(ink: Uint8Array, w: number, h: number): Comp[] {
  const seen = new Uint8Array(w * h);
  const comps: Comp[] = [];
  const stack: number[] = [];
  for (let start = 0; start < w * h; start++) {
    if (!ink[start] || seen[start]) continue;
    stack.length = 0;
    stack.push(start);
    seen[start] = 1;
    let x0 = w;
    let y0 = h;
    let x1 = 0;
    let y1 = 0;
    let area = 0;
    while (stack.length) {
      const p = stack.pop() as number;
      const px = p % w;
      const py = (p - px) / w;
      area++;
      if (px < x0) x0 = px;
      if (px > x1) x1 = px;
      if (py < y0) y0 = py;
      if (py > y1) y1 = py;
      for (let dy = -1; dy <= 1; dy++) {
        const ny = py + dy;
        if (ny < 0 || ny >= h) continue;
        for (let dx = -1; dx <= 1; dx++) {
          const nx = px + dx;
          if (nx < 0 || nx >= w) continue;
          const q = ny * w + nx;
          if (ink[q] && !seen[q]) {
            seen[q] = 1;
            stack.push(q);
          }
        }
      }
    }
    comps.push({ x0, y0, x1, y1, area });
  }
  return comps;
}

function mergeComponents(comps: Comp[], medH: number): Comp[] {
  const refH = Math.max(medH, 4);
  const items = comps.filter((c) => c.area >= 4 && c.x1 - c.x0 + 1 >= 2 && c.y1 - c.y0 + 1 >= 1);
  items.sort((a, b) => a.x0 - b.x0);
  const out: Comp[] = [];
  for (const c of items) {
    const prev = out[out.length - 1];
    if (!prev) {
      out.push({ ...c });
      continue;
    }
    const gap = c.x0 - prev.x1 - 1;
    const overlapTop = Math.max(prev.y0, c.y0);
    const overlapBottom = Math.min(prev.y1, c.y1);
    const vOverlap = overlapBottom - overlapTop + 1;
    const minH = Math.min(prev.y1 - prev.y0 + 1, c.y1 - c.y0 + 1);
    const tiny = minH < refH * 0.3;
    const vGap = c.y0 - prev.y1 - 1;
    if (
      gap <= Math.max(1, refH * 0.2) &&
      (vOverlap > minH * 0.12 || tiny || vGap <= Math.max(3, refH * 0.5))
    ) {
      prev.x1 = Math.max(prev.x1, c.x1);
      prev.y0 = Math.min(prev.y0, c.y0);
      prev.y1 = Math.max(prev.y1, c.y1);
      prev.area += c.area;
      continue;
    }
    out.push({ ...c });
  }
  return out;
}

function splitWide(comps: Comp[], medH: number, ink: Uint8Array, w: number): Comp[] {
  const out: Comp[] = [];
  for (const c of comps) {
    const cw = c.x1 - c.x0 + 1;
    const chh = c.y1 - c.y0 + 1;
    if (cw < medH * 1.7 || chh > medH * 1.8) {
      out.push(c);
      continue;
    }
    const colInk = new Float64Array(cw);
    for (let x = c.x0; x <= c.x1; x++) {
      let s = 0;
      for (let y = c.y0; y <= c.y1; y++) if (ink[y * w + x]) s++;
      colInk[x - c.x0] = s;
    }
    const maxCol = Math.max(...Array.from(colInk));
    const cuts: number[] = [];
    for (let i = 2; i < cw - 2; i++) {
      if (colInk[i] === 0) cuts.push(i);
    }
    if (!cuts.length) {
      for (let i = 3; i < cw - 3; i++) {
        if (colInk[i] < maxCol * 0.14) cuts.push(i);
      }
    }
    if (!cuts.length) {
      out.push(c);
      continue;
    }
    // קבוצות חתך רצופות — לוקחים את מרכז כל קבוצה
    const centers: number[] = [];
    let runStart = cuts[0];
    let runEnd = cuts[0];
    for (let i = 1; i < cuts.length; i++) {
      if (cuts[i] === runEnd + 1) runEnd = cuts[i];
      else {
        centers.push(Math.floor((runStart + runEnd) / 2));
        runStart = cuts[i];
        runEnd = cuts[i];
      }
    }
    centers.push(Math.floor((runStart + runEnd) / 2));
    if (centers.length > 4) {
      out.push(c);
      continue;
    }
    let curX = c.x0;
    for (const cut of centers) {
      const cutAbs = c.x0 + cut;
      out.push({ x0: curX, y0: c.y0, x1: cutAbs - 1, y1: c.y1, area: 1 });
      curX = cutAbs + 1;
    }
    out.push({ x0: curX, y0: c.y0, x1: c.x1, y1: c.y1, area: 1 });
  }
  return out.filter((c) => c.x1 - c.x0 + 1 >= 2 && c.y1 - c.y0 + 1 >= 2);
}

export function segmentLineGlyphs(ink: Uint8Array, w: number, h: number, box: Box): GlyphSeg[] {
  const ox = Math.max(0, box.x);
  const oy = Math.max(0, box.y);
  const x1 = Math.min(w, box.x + box.w);
  const y1 = Math.min(h, box.y + box.h);
  const bw = x1 - ox;
  const bh = y1 - oy;
  if (bw <= 4 || bh <= 4) return [];

  // חיתוך מקומי — מהיר בהרבה מריצה על כל הדף
  const local = new Uint8Array(bw * bh);
  for (let y = 0; y < bh; y++) {
    const src = (oy + y) * w + ox;
    const dst = y * bw;
    for (let x = 0; x < bw; x++) local[dst + x] = ink[src + x];
  }

  const comps = connectedComponents(local, bw, bh);
  const heights = comps.map((c) => c.y1 - c.y0 + 1).sort((a, b) => a - b);
  const medH = Math.max(heights[Math.floor(heights.length / 2)] || bh, bh * 0.2);
  let boxes = mergeComponents(comps, medH);
  boxes = splitWide(boxes, medH, local, bw);

  // סדר מימין לשמאל (עברית)
  boxes.sort((a, b) => b.x0 - a.x0);
  const heights2 = boxes.map((c) => c.y1 - c.y0 + 1).sort((a, b) => a - b);
  const hMed = heights2[Math.floor(heights2.length / 2)] || bh;
  const gaps: number[] = [];
  for (let i = 0; i < boxes.length - 1; i++) {
    const g = boxes[i].x0 - boxes[i + 1].x1 - 1;
    if (g > 0) gaps.push(g);
  }
  gaps.sort((a, b) => a - b);
  const medianGap = gaps.length ? gaps[Math.floor(gaps.length / 2)] : 2;
  const spaceThreshold = Math.max(medianGap * 2.0, hMed * 0.32);

  const out: GlyphSeg[] = [];
  let prev: Comp | null = null;
  for (const c of boxes) {
    const cw = c.x1 - c.x0 + 1;
    const chh = c.y1 - c.y0 + 1;
    const crop = new Uint8Array(cw * chh);
    let inkCount = 0;
    for (let y = c.y0; y <= c.y1; y++) {
      for (let x = c.x0; x <= c.x1; x++) {
        if (local[y * bw + x]) {
          crop[(y - c.y0) * cw + (x - c.x0)] = 1;
          inkCount++;
        }
      }
    }
    const norm = normalizeInk(crop, cw, chh);
    // prev הוא הגליף שמימין לנוכחי (עברית נקראת מימין לשמאל)
    const spaceBefore = prev ? prev.x0 - c.x1 - 1 > spaceThreshold : false;
    const noise = inkCount < 8 || chh < hMed * 0.28 || norm.inkRatio < 0.04;
    out.push({
      box: { x: c.x0 + ox, y: c.y0 + oy, w: cw, h: chh },
      spaceBefore,
      bitmap: packBitmap(norm.bitmap),
      aspect: norm.aspect,
      inkRatio: norm.inkRatio,
      noise,
    });
    prev = c;
  }
  return out;
}

/* ------------------------------ חיתוך תמונות ------------------------------ */

export function cropImageBase64(src: HTMLCanvasElement, box: Box, pad = 3): string {
  const x = Math.max(0, box.x - pad);
  const y = Math.max(0, box.y - pad);
  const w = Math.min(src.width - x, box.w + pad * 2);
  const h = Math.min(src.height - y, box.h + pad * 2);
  const { canvas, ctx } = makeCanvas(w, h);
  ctx.drawImage(src, x, y, w, h, 0, 0, w, h);
  return canvas.toDataURL("image/jpeg", 0.86).split(",")[1] ?? "";
}

export function fullImageBase64(src: HTMLCanvasElement): string {
  return src.toDataURL("image/jpeg", 0.82).split(",")[1] ?? "";
}
