import type { GlyphCandidate } from "./model";
import { isWordChar, stripNiqqud } from "./hebrew";

export type AlignResult = {
  /** תווית לכל גליף (null = גליף שלא שויך, לא נשמר לאימון) */
  labels: (string | null)[];
  matched: number;
  totalChars: number;
};

const GLYPH_SKIP = 0.9;
const CHAR_SKIP = 1.0;

function usableChar(ch: string): boolean {
  return isWordChar(ch) || ".,?!:;()[]{}\"'-–—%$".includes(ch);
}

/**
 * התאמת גליפים שנחתכו מהשורה אל הטקסט שהמשתמש הקליד (Needleman–Wunsch).
 * התוצאה היא תיוג אמת לכל גליף — זה מה שנכנס לאימון המודל.
 */
export function alignGlyphsToText(candidates: GlyphCandidate[][], text: string): AlignResult {
  const chars = Array.from(stripNiqqud(text)).filter(usableChar);
  const n = candidates.length;
  const m = chars.length;
  const labels: (string | null)[] = new Array(n).fill(null);
  if (n === 0 || m === 0) return { labels, matched: 0, totalChars: m };

  const matchCost = (gi: number, ci: number): number => {
    const cands = candidates[gi];
    const ch = chars[ci];
    if (!cands.length) return 0.75;
    const best = cands[0];
    if (best.label === ch) return 0;
    if (cands.some((c) => c.label === ch)) return 0.22;
    // אות סופית/רגילה או תו דומה — קנס בינוני
    return 1.15;
  };

  const INF = 1e9;
  const dp: number[][] = [];
  for (let i = 0; i <= n; i++) dp.push(new Array<number>(m + 1).fill(INF));
  dp[0][0] = 0;
  for (let i = 0; i <= n; i++) {
    for (let j = 0; j <= m; j++) {
      const cur = dp[i][j];
      if (cur >= INF) continue;
      if (i < n) dp[i + 1][j] = Math.min(dp[i + 1][j], cur + GLYPH_SKIP);
      if (j < m) dp[i][j + 1] = Math.min(dp[i][j + 1], cur + CHAR_SKIP);
      if (i < n && j < m) dp[i + 1][j + 1] = Math.min(dp[i + 1][j + 1], cur + matchCost(i, j));
    }
  }
  // traceback
  let i = n;
  let j = m;
  while (i > 0 && j > 0) {
    const here = dp[i][j];
    const sub = dp[i - 1][j - 1] + matchCost(i - 1, j - 1);
    const del = dp[i - 1][j] + GLYPH_SKIP;
    const ins = dp[i][j - 1] + CHAR_SKIP;
    if (Math.abs(sub - here) < 1e-9) {
      labels[i - 1] = chars[j - 1];
      i--;
      j--;
    } else if (Math.abs(del - here) < 1e-9) {
      i--;
    } else {
      j--;
    }
  }
  const matched = labels.filter((l) => l !== null).length;
  return { labels, matched, totalChars: m };
}
