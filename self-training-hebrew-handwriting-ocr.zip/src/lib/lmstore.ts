import { db } from "@/db";
import { lmBigrams, lmChars, lmWords, substitutions } from "@/db/schema";
import { sql } from "drizzle-orm";
import { isWordChar, stripNiqqud } from "./hebrew";

export function tokenize(text: string): string[] {
  const clean = stripNiqqud(text);
  const tokens = clean.split(/\s+/).map((t) => t.replace(/[^\p{L}\p{N}'\-]/gu, "")).filter(Boolean);
  return tokens;
}

function bump(map: Map<string, number>, key: string, by = 1) {
  map.set(key, (map.get(key) ?? 0) + by);
}

/** מעדכן את מודל השפה מטקסט שאושר על ידי המשתמש */
export async function recordCorrectedText(text: string): Promise<void> {
  const tokens = tokenize(text).slice(0, 400);
  if (!tokens.length) return;

  const wordCounts = new Map<string, number>();
  const bigramCounts = new Map<string, number>();
  const charCounts = new Map<string, number>();

  tokens.forEach((t) => {
    if (t.length < 2) return;
    bump(wordCounts, t);
  });
  for (let i = 0; i < tokens.length - 1; i++) {
    const a = tokens[i];
    const b = tokens[i + 1];
    if (a.length < 2 || b.length < 2) continue;
    bump(bigramCounts, `${a}\u0001${b}`);
  }
  for (const t of tokens) {
    const padded = `\u0002${t}\u0003`;
    for (let i = 0; i < padded.length; i++) {
      bump(charCounts, padded[i]);
      if (i >= 1) bump(charCounts, padded.slice(i - 1, i + 1));
      if (i >= 2) bump(charCounts, padded.slice(i - 2, i + 1));
    }
  }

  const wordRows = [...wordCounts.entries()].map(([word, count]) => ({ word, count }));
  if (wordRows.length) {
    await db
      .insert(lmWords)
      .values(wordRows)
      .onConflictDoUpdate({ target: lmWords.word, set: { count: sql`${lmWords.count} + excluded.count` } });
  }

  const bigramRows = [...bigramCounts.entries()].map(([k, count]) => {
    const i = k.indexOf("\u0001");
    return { w1: k.slice(0, i), w2: k.slice(i + 1), count };
  });
  if (bigramRows.length) {
    await db
      .insert(lmBigrams)
      .values(bigramRows)
      .onConflictDoUpdate({
        target: [lmBigrams.w1, lmBigrams.w2],
        set: { count: sql`${lmBigrams.count} + excluded.count` },
      });
  }

  const charRows = [...charCounts.entries()].map(([ngram, count]) => ({ ngram, count }));
  if (charRows.length) {
    await db
      .insert(lmChars)
      .values(charRows)
      .onConflictDoUpdate({ target: lmChars.ngram, set: { count: sql`${lmChars.count} + excluded.count` } });
  }
}

/** תיעוד תיקונים: מילה שגויה שהוחלפה במילה נכונה */
export async function recordSubstitutions(raw: string, corrected: string): Promise<void> {
  const a = tokenize(raw);
  const b = tokenize(corrected);
  if (!a.length || a.length !== b.length) return;
  const counts = new Map<string, number>();
  for (let i = 0; i < a.length; i++) {
    if (a[i] === b[i]) continue;
    if (!isWordChar(a[i][0] ?? "")) continue;
    bump(counts, `${a[i]}\u0001${b[i]}`);
  }
  const rows = [...counts.entries()].map(([k, count]) => {
    const i = k.indexOf("\u0001");
    return { wrong: k.slice(0, i), right: k.slice(i + 1), count };
  });
  if (!rows.length) return;
  await db
    .insert(substitutions)
    .values(rows)
    .onConflictDoUpdate({
      target: [substitutions.wrong, substitutions.right],
      set: { count: sql`${substitutions.count} + excluded.count` },
    });
}
