import type { Box } from "./vision";

export type TessLine = { text: string; box: Box };

/**
 * מחלץ שורות ממבנה ה-blocks של tesseract.js:
 * blocks (מערך) → paragraphs → lines (לכל שורה text + bbox).
 * לא יורדים למילים (words) — השורה כיחידה היא מה שמשתלב עם תיבות השורות שלנו.
 */
export function collectLines(node: unknown, out: TessLine[], depth = 0): void {
  if (!node || typeof node !== "object" || depth > 6) return;
  if (Array.isArray(node)) {
    for (const child of node) collectLines(child, out, depth + 1);
    return;
  }
  const obj = node as Record<string, unknown>;
  let recursed = false;
  for (const key of ["blocks", "paragraphs", "lines"]) {
    const arr = obj[key];
    if (Array.isArray(arr)) {
      recursed = true;
      for (const child of arr) collectLines(child, out, depth + 1);
    }
  }
  if (recursed) return;
  const bbox = obj.bbox as { x0: number; y0: number; x1: number; y1: number } | undefined;
  const text = obj.text;
  if (bbox && typeof text === "string" && text.trim().length) {
    out.push({
      text: text.replace(/\s+/g, " ").trim(),
      box: { x: bbox.x0, y: bbox.y0, w: bbox.x1 - bbox.x0, h: bbox.y1 - bbox.y0 },
    });
  }
}

export function flattenTessBlocks(blocks: unknown): TessLine[] {
  const out: TessLine[] = [];
  collectLines(blocks, out);
  return out.sort((a, b) => a.box.y - b.box.y);
}
