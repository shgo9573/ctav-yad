import fs from "node:fs";
import path from "node:path";
import type { AdaptJob, RoundInfo } from "../apiTypes";
import { isHeldOutId } from "../split";
import { prefixBeamDecode, headLogprobs, lse } from "./decode";
import {
  decodeGray,
  getActiveHead,
  getCore,
  backboneFeatures,
  HEADS_DIR,
  readHeadFile,
  writeHeadFile,
  type Core,
  type Head,
} from "./engine";
import { preprocess } from "./preprocess";

/** פרמטרי האימון מתוך spec/adapter.md (adapt.json) */
const STEPS = 100;
const LR = 1e-3;
const B1 = 0.9;
const B2 = 0.999;
const EPS = 1e-8;
const L2 = 0.1;
// תקרה לזמן האימון: עלות כל צעד יחסית לאורך השורות. 60 השורות האחרונות ≈ כמה דקות על מחשב רגיל
const MAX_TRAIN = 60;
const MAX_HELD = 20;
const NEG = -1e30;
const NEG_HALF = -1e29;

export type Sample = { id: number; text: string; jpeg: Buffer };
type Prepared = { id: number; labels: number[]; target: string; feat: Float32Array; T: number; D: number };

const ROUNDS_FILE = path.join(HEADS_DIR, "rounds.json");
const CURRENT_FILE = path.join(HEADS_DIR, "current.json");

export function readRounds(): RoundInfo[] {
  if (!fs.existsSync(ROUNDS_FILE)) return [];
  try {
    return JSON.parse(fs.readFileSync(ROUNDS_FILE, "utf8")) as RoundInfo[];
  } catch {
    return [];
  }
}

function appendRound(r: RoundInfo) {
  const all = readRounds();
  all.push(r);
  fs.mkdirSync(HEADS_DIR, { recursive: true });
  fs.writeFileSync(ROUNDS_FILE, JSON.stringify(all, null, 2), "utf8");
}

export function currentRound(): { round: number; file: string | null } {
  if (!fs.existsSync(CURRENT_FILE)) return { round: 0, file: null };
  try {
    const m = JSON.parse(fs.readFileSync(CURRENT_FILE, "utf8")) as { round: number; file: string };
    return { round: m.round, file: m.file };
  } catch {
    return { round: 0, file: null };
  }
}

/* ------------------------------ CTC (לפי spec) ------------------------------ */

/** הפסד CTC ונגזרת לפי הלוגיטים: dz = exp(lp) − posterior */
function ctcGrad(lp: Float64Array, T: number, C: number, labels: number[]) {
  const L = labels.length;
  const S = 2 * L + 1;
  const ext = (s: number) => (s % 2 === 0 ? 0 : labels[(s - 1) / 2]);
  const canSkip = (s: number) => s >= 2 && ext(s) !== 0 && ext(s) !== ext(s - 2);

  const alpha = new Float64Array(T * S).fill(NEG);
  alpha[0] = lp[ext(0)];
  if (S > 1) alpha[1] = lp[ext(1)];
  for (let t = 1; t < T; t++) {
    for (let s = 0; s < S; s++) {
      let v = alpha[(t - 1) * S + s];
      if (s >= 1) v = lse(v, alpha[(t - 1) * S + s - 1]);
      if (canSkip(s)) v = lse(v, alpha[(t - 1) * S + s - 2]);
      alpha[t * S + s] = v <= NEG_HALF ? NEG : v + lp[t * C + ext(s)];
    }
  }
  const logZ = S > 1 ? lse(alpha[(T - 1) * S + S - 1], alpha[(T - 1) * S + S - 2]) : alpha[(T - 1) * S + S - 1];
  if (!(logZ > NEG_HALF)) return null;

  const beta = new Float64Array(T * S).fill(NEG);
  beta[(T - 1) * S + S - 1] = 0;
  if (S > 1) beta[(T - 1) * S + S - 2] = 0;
  for (let t = T - 2; t >= 0; t--) {
    for (let s = 0; s < S; s++) {
      let v = NEG;
      v = lse(v, beta[(t + 1) * S + s] + lp[(t + 1) * C + ext(s)]);
      if (s + 1 < S) v = lse(v, beta[(t + 1) * S + s + 1] + lp[(t + 1) * C + ext(s + 1)]);
      if (s + 2 < S && canSkip(s + 2)) v = lse(v, beta[(t + 1) * S + s + 2] + lp[(t + 1) * C + ext(s + 2)]);
      beta[t * S + s] = v <= NEG_HALF ? NEG : v;
    }
  }

  const dz = new Float64Array(T * C);
  for (let i = 0; i < T * C; i++) dz[i] = Math.exp(lp[i]);
  for (let t = 0; t < T; t++) {
    for (let s = 0; s < S; s++) {
      const a = alpha[t * S + s];
      const b = beta[t * S + s];
      if (a <= NEG_HALF || b <= NEG_HALF) continue;
      dz[t * C + ext(s)] -= Math.exp(a + b - logZ);
    }
  }
  return { loss: -logZ, dz };
}

function levenshtein(a: string, b: string): number {
  const n = a.length;
  const m = b.length;
  let prev = Array.from({ length: m + 1 }, (_, j) => j);
  for (let i = 1; i <= n; i++) {
    const cur = [i];
    for (let j = 1; j <= m; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    prev = cur;
  }
  return prev[m];
}

/** טקסט → אינדקסי charset (תווים שלא ב-charset נופלים) */
export function encodeText(text: string, core: Core): number[] {
  const out: number[] = [];
  for (const ch of text.replace(/\s+/g, " ").trim()) {
    const i = core.charIndex.get(ch);
    if (i !== undefined && i !== 0) out.push(i);
  }
  return out;
}

async function prepare(core: Core, samples: Sample[]): Promise<Prepared[]> {
  const out: Prepared[] = [];
  for (const s of samples) {
    const labels = encodeText(s.text, core);
    if (!labels.length) continue;
    const pre = preprocess(decodeGray(s.jpeg));
    const { feat, T, D } = await backboneFeatures(core, pre.data, pre.w);
    out.push({ id: s.id, labels, target: labels.map((i) => core.charset[i]).join(""), feat, T, D });
    await tick();
  }
  return out;
}

function tick(): Promise<void> {
  return new Promise((r) => setImmediate(r));
}

function charAccuracy(core: Core, head: Head, items: Prepared[]): number | null {
  if (!items.length) return null;
  let ed = 0;
  let total = 0;
  for (const p of items) {
    const lp = headLogprobs(p.feat, p.T, p.D, head);
    const hyp = prefixBeamDecode(lp, p.T, head.classes, core.charset, core.charLM, core.words);
    ed += levenshtein(hyp.text.trim(), p.target);
    total += p.target.length;
  }
  return total ? 1 - ed / total : null;
}

export type Progress = (phase: string, step: number, steps: number) => void;

/** סבב אימון אחד: ראש CTC מאומן מהראש הכללי על השורות שתיקנת, עם בדיקת holdout */
export async function trainHeadRound(samples: Sample[], onProgress: Progress): Promise<RoundInfo> {
  const started = Date.now();
  const core = await getCore();
  const active = getActiveHead(core);
  const base = core.baseHead;
  const C = base.classes;
  const D = base.dim;

  onProgress("מחלץ תכונות מהשורות", 0, STEPS);
  const labeled = samples.filter((s) => s.text.trim().length > 0);
  const trainSet = labeled.filter((s) => !isHeldOutId(s.id)).slice(0, MAX_TRAIN);
  const heldSet = labeled.filter((s) => isHeldOutId(s.id)).slice(0, MAX_HELD);
  const train = await prepare(core, trainSet);
  const held = await prepare(core, heldSet);
  const usable = train.filter((p) => p.T >= 1);
  const roundNo = Math.max(active.round, ...readRounds().map((r) => r.round)) + 1;

  const fail = (reason: string): RoundInfo => {
    const r: RoundInfo = {
      round: roundNo,
      accepted: false,
      reason,
      trainSamples: usable.length,
      heldOut: held.length,
      accBefore: null,
      accAfter: null,
      loss0: NaN,
      loss1: NaN,
      steps: 0,
      durationMs: Date.now() - started,
      at: new Date().toISOString(),
    };
    appendRound(r);
    return r;
  };
  if (!usable.length) return fail("אין מספיק שורות מתויגות (צריך לתקן ולשמור שורות קודם)");

  const W = Float64Array.from(base.W);
  const b = Float64Array.from(base.b);
  const W0 = Float64Array.from(base.W);
  const b0 = Float64Array.from(base.b);
  const nP = C * D + C;
  const m = new Float64Array(nP);
  const v = new Float64Array(nP);
  let loss0 = NaN;
  let loss1 = NaN;
  let stepsDone = 0;

  for (let step = 1; step <= STEPS; step++) {
    const gW = new Float64Array(C * D);
    const gb = new Float64Array(C);
    let lossSum = 0;
    let n = 0;
    for (const p of usable) {
      const lp = headLogprobs(p.feat, p.T, D, { W, b, classes: C });
      const r = ctcGrad(lp, p.T, C, p.labels);
      if (!r) continue;
      n++;
      const sc = 1 / p.labels.length;
      lossSum += r.loss * sc;
      for (let t = 0; t < p.T; t++) {
        const fo = t * D;
        for (let k = 0; k < C; k++) {
          const g = r.dz[t * C + k] * sc;
          if (g === 0) continue;
          gb[k] += g;
          const wo = k * D;
          for (let d = 0; d < D; d++) gW[wo + d] += g * p.feat[fo + d];
        }
      }
    }
    if (n === 0) break;

    let reg = 0;
    for (let i = 0; i < C * D; i++) {
      const diff = W[i] - W0[i];
      reg += diff * diff;
      gW[i] = gW[i] / n + 2 * L2 * diff;
    }
    for (let k = 0; k < C; k++) {
      const diff = b[k] - b0[k];
      reg += diff * diff;
      gb[k] = gb[k] / n + 2 * L2 * diff;
    }
    const loss = lossSum / n + L2 * reg;
    if (step === 1) loss0 = loss;
    loss1 = loss;

    // Adam (bias-corrected), עדכון מלא
    const bc1 = 1 - Math.pow(B1, step);
    const bc2 = 1 - Math.pow(B2, step);
    for (let i = 0; i < nP; i++) {
      const isW = i < C * D;
      const g = isW ? gW[i] : gb[i - C * D];
      m[i] = B1 * m[i] + (1 - B1) * g;
      v[i] = B2 * v[i] + (1 - B2) * g * g;
      const upd = (LR * (m[i] / bc1)) / (Math.sqrt(v[i] / bc2) + EPS);
      if (isW) W[i] -= upd;
      else b[i - C * D] -= upd;
    }
    stepsDone = step;
    onProgress("מאמן את ראש ה-CTC", step, STEPS);
    await tick();
  }

  const newHead: Head = {
    W: Float32Array.from(W),
    b: Float32Array.from(b),
    classes: C,
    dim: D,
  };

  onProgress("בודק על שורות שלא נלמדו", STEPS, STEPS);
  const accBefore = charAccuracy(core, active.head, held);
  const accAfter = charAccuracy(core, newHead, held);
  const accepted = accBefore === null || accAfter === null || accAfter >= accBefore;
  const reason =
    accBefore === null
      ? "אין שורות בדיקה (holdout) — הסבב התקבל ללא בדיקה"
      : accepted
        ? `דיוק בדיקה ${(accBefore * 100).toFixed(1)}% → ${(accAfter! * 100).toFixed(1)}%`
        : `נדחה: הדיוק בבדיקה ירד ${(accBefore * 100).toFixed(1)}% → ${(accAfter! * 100).toFixed(1)}%`;

  const result: RoundInfo = {
    round: roundNo,
    accepted,
    reason,
    trainSamples: usable.length,
    heldOut: held.length,
    accBefore,
    accAfter,
    loss0,
    loss1,
    steps: stepsDone,
    durationMs: Date.now() - started,
    at: new Date().toISOString(),
  };
  if (accepted) {
    const file = `head-r${roundNo}.bin`;
    writeHeadFile(path.join(HEADS_DIR, file), newHead);
    fs.writeFileSync(CURRENT_FILE, JSON.stringify({ file, round: roundNo, updatedAt: result.at }, null, 2), "utf8");
  }
  appendRound(result);
  return result;
}

/* ------------------------------ ניהול משימת אימון ------------------------------ */

const JOB_KEY = "__mishkefetAdaptJob";

function emptyJob(): AdaptJob {
  return {
    running: false,
    phase: "ממתין",
    step: 0,
    steps: STEPS,
    samples: 0,
    startedAt: null,
    finishedAt: null,
    error: null,
    result: null,
  };
}

function jobRef(): AdaptJob {
  const g = globalThis as Record<string, unknown>;
  if (!g[JOB_KEY]) g[JOB_KEY] = emptyJob();
  return g[JOB_KEY] as AdaptJob;
}

export function getJob(): AdaptJob {
  return { ...jobRef() };
}

/** מתחיל אימון ברקע (משימה אחת בכל רגע); מחזיר את מצב המשימה מיד */
export function startAdapt(samples: Sample[]): AdaptJob {
  const job = jobRef();
  if (job.running) return { ...job };
  Object.assign(job, {
    running: true,
    phase: "מתחיל",
    step: 0,
    steps: STEPS,
    samples: samples.length,
    startedAt: new Date().toISOString(),
    finishedAt: null,
    error: null,
    result: null,
  });
  void (async () => {
    try {
      const result = await trainHeadRound(samples, (phase, step, steps) => {
        Object.assign(job, { phase, step, steps });
      });
      job.result = result;
      job.phase = result.accepted ? "הושלם — הסבב התקבל" : "הושלם — הסבב נדחה";
    } catch (err) {
      job.error = err instanceof Error ? err.message : String(err);
      job.phase = "נכשל";
    } finally {
      job.running = false;
      job.finishedAt = new Date().toISOString();
    }
  })();
  return { ...job };
}
