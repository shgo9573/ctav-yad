/**
 * קריאת מודלי השפה של Mishkefet-v1 (spec/lm-format.md):
 * charlm.bin — trigram/6-gram תווים בעץ, backoff סטופ; words.bin — מילון unigram.
 */

/** charlm.bin: stupid-backoff character 6-gram כעץ בפורמט level-order */
export class CharLM {
  readonly order: number;
  readonly logBackoff: number;
  readonly logFloor: number;
  readonly scale: number;
  private counts: number[] = [0];
  private childOff: number[] = [];
  private qOff: number[] = [];
  private charOff: number[] = [];

  constructor(private buf: Buffer) {
    if (buf.toString("ascii", 0, 4) !== "MKL1") throw new Error("charlm.bin: magic לא תקין");
    this.order = buf.readUInt32LE(4);
    this.logBackoff = buf.readFloatLE(8);
    this.logFloor = buf.readFloatLE(12);
    this.scale = buf.readFloatLE(16);
    let off = 24;
    for (let L = 1; L <= this.order; L++) {
      this.counts[L] = buf.readUInt32LE(off);
      off += 4;
    }
    for (let L = 1; L < this.order; L++) {
      this.childOff[L] = off;
      off += 4 * (this.counts[L] + 1);
    }
    for (let L = 1; L <= this.order; L++) {
      this.qOff[L] = off;
      off += 2 * this.counts[L];
    }
    for (let L = 1; L <= this.order; L++) {
      this.charOff[L] = off;
      off += this.counts[L];
    }
    if (off !== buf.length) throw new Error(`charlm.bin: גודל לא תואם (${off} != ${buf.length})`);
  }

  private childRange(L: number, i: number): [number, number] {
    const base = this.childOff[L] + 4 * i;
    return [this.buf.readUInt32LE(base), this.buf.readUInt32LE(base + 4)];
  }

  private search(L: number, lo: number, hi: number, c: number): number {
    const off = this.charOff[L];
    let a = lo;
    let b = hi - 1;
    while (a <= b) {
      const m = (a + b) >> 1;
      const v = this.buf[off + m];
      if (v === c) return m;
      if (v < c) a = m + 1;
      else b = m - 1;
    }
    return -1;
  }

  /** מחזיר אינדקס צומת ברמה seq.length, או -1 */
  private find(seq: number[]): number {
    let lo = 0;
    let hi = this.counts[1];
    let node = -1;
    for (let L = 1; L <= seq.length; L++) {
      const idx = this.search(L, lo, hi, seq[L - 1]);
      if (idx < 0) return -1;
      node = idx;
      if (L < seq.length) [lo, hi] = this.childRange(L, idx);
    }
    return node;
  }

  private q(L: number, i: number): number {
    return this.buf.readUInt16LE(this.qOff[L] + 2 * i);
  }

  /** log P(c | context), עם backoff; context = עד 5 התווים האחרונים */
  logprob(context: number[], c: number): number {
    const ctx = context.length > 5 ? context.slice(-5) : context;
    let penalty = 0;
    for (let L = ctx.length; L >= 0; L--) {
      const seq = ctx.slice(ctx.length - L).concat([c]);
      const node = this.find(seq);
      if (node >= 0) {
        const q = this.q(seq.length, node);
        if (q !== 65535) return penalty - q / this.scale;
      }
      penalty += this.logBackoff;
    }
    return penalty + this.logFloor;
  }
}

const PREFIX_LETTERS = ["ב", "ה", "ו", "כ", "ל", "מ", "ש"];

/** words.bin: מילון unigram, מילים כאינדקסי charset ממוינות בייט-בייט */
export class WordLM {
  readonly n: number;
  readonly oov: number;
  readonly discount: number;
  readonly scale: number;
  private offsets: Uint32Array;
  private q: Uint16Array;
  private blob: Buffer;
  private prefixSet: Set<number>;

  constructor(buf: Buffer, charIndex: Map<string, number>) {
    if (buf.toString("ascii", 0, 4) !== "MKW1") throw new Error("words.bin: magic לא תקין");
    this.n = buf.readUInt32LE(4);
    this.oov = buf.readFloatLE(8);
    this.discount = buf.readFloatLE(12);
    this.scale = buf.readFloatLE(16);
    const offStart = 24;
    const qStart = offStart + 4 * (this.n + 1);
    const blobStart = qStart + 2 * this.n;
    this.offsets = new Uint32Array(this.n + 1);
    for (let i = 0; i <= this.n; i++) this.offsets[i] = buf.readUInt32LE(offStart + 4 * i);
    this.q = new Uint16Array(this.n);
    for (let i = 0; i < this.n; i++) this.q[i] = buf.readUInt16LE(qStart + 2 * i);
    this.blob = buf.subarray(blobStart);
    this.prefixSet = new Set(
      PREFIX_LETTERS.map((ch) => charIndex.get(ch)).filter((x): x is number => x !== undefined),
    );
  }

  private cmp(i: number, t: number[]): number {
    const s = this.offsets[i];
    const e = this.offsets[i + 1];
    const len = Math.min(e - s, t.length);
    for (let k = 0; k < len; k++) {
      const x = this.blob[s + k];
      const y = t[k];
      if (x !== y) return x < y ? -1 : 1;
    }
    const wl = e - s;
    if (wl === t.length) return 0;
    return wl < t.length ? -1 : 1;
  }

  private find(t: number[]): number {
    let lo = 0;
    let hi = this.n - 1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      const c = this.cmp(mid, t);
      if (c === 0) return mid;
      if (c < 0) lo = mid + 1;
      else hi = mid - 1;
    }
    return -1;
  }

  logprob(word: number[]): number {
    if (!word.length) return 0;
    const i = this.find(word);
    if (i >= 0) return -this.q[i] / this.scale;
    if (word.length > 2 && this.prefixSet.has(word[0])) {
      const j = this.find(word.slice(1));
      if (j >= 0) return -this.q[j] / this.scale + this.discount;
    }
    return this.oov;
  }

  /** בונוס מילה (0 לא-מילה) — משמש להטיית פענוח */
  bonus(word: number[]): number {
    return Math.max(0, this.logprob(word) - this.oov);
  }
}
