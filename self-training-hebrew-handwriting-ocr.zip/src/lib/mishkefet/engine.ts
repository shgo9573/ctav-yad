import fs from "node:fs";
import path from "node:path";
import * as ort from "onnxruntime-node";
import { decode as decodeJpeg } from "jpeg-js";
import { CharLM, WordLM } from "./lm";
import { allFrameConfidence, emittingConfidence, headLogprobs, prefixBeamDecode } from "./decode";
import { grayFromRgba, LINE_HEIGHT, preprocess, ttaView, type GrayImage } from "./preprocess";

export const MODEL_NAME = "Mishkefet-v1";
export const MODEL_LICENSE = "CC-BY-NC-SA-4.0";
export const MODEL_DIR = path.join(process.cwd(), "models", "mishkefet");
export const HEADS_DIR = path.join(process.cwd(), "data", "heads");
const TTA_SCALES = [1.0, 0.82, 1.22];

export type Head = { W: Float32Array; b: Float32Array; classes: number; dim: number };

export type Core = {
  session: ort.InferenceSession;
  inputName: string;
  outputName: string;
  charset: string[];
  charIndex: Map<string, number>;
  charLM: CharLM;
  words: WordLM;
  baseHead: Head;
};

export type LineResult = { text: string; confidence: number; scale: number };

/** קורא קובץ ראש בפורמט MKH1 */
export function readHeadFile(file: string): Head {
  const buf = fs.readFileSync(file);
  if (buf.toString("ascii", 0, 4) !== "MKH1") throw new Error(`${path.basename(file)}: magic לא תקין`);
  const classes = buf.readUInt32LE(4);
  const dim = buf.readUInt32LE(8);
  const expected = 12 + 4 * classes * dim + 4 * classes;
  if (buf.length !== expected) throw new Error(`${path.basename(file)}: גודל לא תואם`);
  const ab = buf.buffer.slice(buf.byteOffset + 12, buf.byteOffset + expected);
  const all = new Float32Array(ab);
  return {
    W: all.subarray(0, classes * dim),
    b: all.subarray(classes * dim),
    classes,
    dim,
  };
}

export function writeHeadFile(file: string, head: Head): void {
  const n = head.classes * head.dim + head.classes;
  const out = Buffer.alloc(12 + 4 * n);
  out.write("MKH1", 0, "ascii");
  out.writeUInt32LE(head.classes, 4);
  out.writeUInt32LE(head.dim, 8);
  let o = 12;
  for (let i = 0; i < head.W.length; i++, o += 4) out.writeFloatLE(head.W[i], o);
  for (let i = 0; i < head.b.length; i++, o += 4) out.writeFloatLE(head.b[i], o);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, out);
}

async function loadCore(): Promise<Core> {
  const charset = JSON.parse(fs.readFileSync(path.join(MODEL_DIR, "charset.json"), "utf8")) as string[];
  const charIndex = new Map<string, number>();
  charset.forEach((c, i) => charIndex.set(c, i));
  // graphOptimizationLevel=disabled: בלי זה onnxruntime-node קורס (segfault) על מודל ה-fp16 בסביבה הזו
  const session = await ort.InferenceSession.create(path.join(MODEL_DIR, "backbone.fp16.onnx"), {
    executionProviders: ["cpu"],
    graphOptimizationLevel: "disabled",
  });
  return {
    session,
    inputName: session.inputNames[0],
    outputName: session.outputNames[0],
    charset,
    charIndex,
    charLM: new CharLM(fs.readFileSync(path.join(MODEL_DIR, "charlm.bin"))),
    words: new WordLM(fs.readFileSync(path.join(MODEL_DIR, "words.bin")), charIndex),
    baseHead: readHeadFile(path.join(MODEL_DIR, "head.bin")),
  };
}

const CORE_KEY = "__mishkefetCorePromise";

/** טעינה חד-פעמית של המודל (נשמר ב-globalThis כדי לשרוד hot reload בפיתוח) */
export function getCore(): Promise<Core> {
  const g = globalThis as Record<string, unknown>;
  if (!g[CORE_KEY]) {
    g[CORE_KEY] = loadCore().catch((err: unknown) => {
      g[CORE_KEY] = undefined;
      throw err;
    });
  }
  return g[CORE_KEY] as Promise<Core>;
}

/** הראש הפעיל: הגרסה האחרונה שהתקבלה באימון, או הראש הכללי */
export function getActiveHead(core: Core): { head: Head; round: number; file: string | null } {
  const metaPath = path.join(HEADS_DIR, "current.json");
  if (fs.existsSync(metaPath)) {
    try {
      const meta = JSON.parse(fs.readFileSync(metaPath, "utf8")) as { file: string; round: number };
      const file = path.join(HEADS_DIR, meta.file);
      if (fs.existsSync(file)) return { head: readHeadFile(file), round: meta.round, file: meta.file };
    } catch {
      /* נופלים לראש הכללי */
    }
  }
  return { head: core.baseHead, round: 0, file: null };
}

/** מפענח JPEG/PNG של שורה לאפור */
export function decodeGray(jpeg: Buffer): GrayImage {
  const img = decodeJpeg(jpeg, { useTArray: true, formatAsRGBA: true });
  return { data: grayFromRgba(img.data, img.width, img.height), w: img.width, h: img.height };
}

/** תכונות ה-backbone לתצוגה אחת (כבר מעובדת) */
export async function backboneFeatures(
  core: Core,
  data: Float32Array,
  w: number,
): Promise<{ feat: Float32Array; T: number; D: number }> {
  const input = new ort.Tensor("float32", data, [1, 1, LINE_HEIGHT, w]);
  const out = await core.session.run({ [core.inputName]: input });
  const o = out[core.outputName] as ort.Tensor;
  const dims = o.dims;
  const T = Number(dims[1]);
  const D = Number(dims[2]);
  // הפלט כבר בסדר קריאה (spec/decoder.md: "logical order already") — בלי היפוך של ציר הזמן
  return { feat: Float32Array.from(o.data as Float32Array), T, D };
}

/** קריאת שורה עם TTA (3 תצוגות), לפי spec/decoder.md */
export async function readGray(core: Core, img: GrayImage, head: Head): Promise<LineResult> {
  let best: { score: number; text: string; scale: number } | null = null;
  let conf = 0;
  for (const s of TTA_SCALES) {
    const view = ttaView(img, s);
    const pre = preprocess(view);
    const { feat, T, D } = await backboneFeatures(core, pre.data, pre.w);
    const C = head.classes;
    const lp = headLogprobs(feat, T, D, head);
    const hyp = prefixBeamDecode(lp, T, C, core.charset, core.charLM, core.words);
    const text = hyp.text.trim();
    const score = text ? emittingConfidence(lp, T, C) : -Infinity;
    if (s === 1) conf = allFrameConfidence(lp, T, C);
    if (!best || score > best.score) best = { score, text, scale: s };
  }
  const chosen = best ?? { score: 0, text: "", scale: 1 };
  return { text: chosen.text, confidence: conf, scale: chosen.scale };
}

/** מזהה תמונת שורה (JPEG) עם הראש הפעיל */
export async function recognizeJpeg(jpeg: Buffer): Promise<LineResult & { round: number }> {
  const core = await getCore();
  const active = getActiveHead(core);
  const r = await readGray(core, decodeGray(jpeg), active.head);
  return { ...r, round: active.round };
}
