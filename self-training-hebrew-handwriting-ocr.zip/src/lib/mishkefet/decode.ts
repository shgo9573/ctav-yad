/** פענוח (spec/decoder.md): greedy, prefix beam search עם LM תווים ומילון, וביטחון */

export const BLANK = 0;
export const SPACE = 38;
const NEG_HALF = -1e29;

export function lse(a: number, b: number): number {
  if (a <= NEG_HALF) return b;
  if (b <= NEG_HALF) return a;
  const hi = a > b ? a : b;
  const lo = a > b ? b : a;
  return hi + Math.log1p(Math.exp(lo - hi));
}

/** ראש CTC: logits = F·Wᵀ + b ואז log-softmax (בדיוק בשלב float64) */
export function headLogprobs(
  feat: ArrayLike<number>,
  T: number,
  D: number,
  head: { W: ArrayLike<number>; b: ArrayLike<number>; classes: number },
): Float64Array {
  const C = head.classes;
  const out = new Float64Array(T * C);
  const z = new Float64Array(C);
  for (let t = 0; t < T; t++) {
    const fo = t * D;
    let m = -Infinity;
    for (let k = 0; k < C; k++) {
      let s = head.b[k];
      const wo = k * D;
      for (let d = 0; d < D; d++) s += feat[fo + d] * head.W[wo + d];
      z[k] = s;
      if (s > m) m = s;
    }
    let sum = 0;
    for (let k = 0; k < C; k++) sum += Math.exp(z[k] - m);
    const lz = m + Math.log(sum);
    for (let k = 0; k < C; k++) out[t * C + k] = z[k] - lz;
  }
  return out;
}

function argmaxRow(lp: Float64Array, row: number, C: number): number {
  let best = 0;
  for (let k = 1; k < C; k++) if (lp[row + k] > lp[row + best]) best = k;
  return best;
}

export function greedyDecode(lp: Float64Array, T: number, C: number, charset: string[]): string {
  let out = "";
  let prev = -1;
  for (let t = 0; t < T; t++) {
    const k = argmaxRow(lp, t * C, C);
    if (k !== prev && k !== BLANK) out += charset[k];
    prev = k;
  }
  return out;
}

/** ביטחון כולל: ממוצע הסתברות המקסימום על כל הפריימים */
export function allFrameConfidence(lp: Float64Array, T: number, C: number): number {
  if (T === 0) return 0;
  let s = 0;
  for (let t = 0; t < T; t++) s += Math.exp(lp[t * C + argmaxRow(lp, t * C, C)]);
  return s / T;
}

/** ביטחון פולט: רק פריימים שאינם blank ושונים מהפריים הקודם — לבחירה בין תצוגות TTA */
export function emittingConfidence(lp: Float64Array, T: number, C: number): number {
  let s = 0;
  let n = 0;
  let prev = -1;
  for (let t = 0; t < T; t++) {
    const k = argmaxRow(lp, t * C, C);
    if (k !== BLANK && k !== prev) {
      s += Math.exp(lp[t * C + k]);
      n++;
    }
    prev = k;
  }
  return n ? s / n : 0;
}

export interface CharLMLike {
  logprob(context: number[], c: number): number;
}
export interface WordLMLike {
  bonus(word: number[]): number;
}

function topK(lp: Float64Array, row: number, C: number, k: number): number[] {
  const idx = Array.from({ length: C }, (_, i) => i);
  idx.sort((a, b) => lp[row + b] - lp[row + a] || a - b);
  return idx.slice(0, k);
}

function lastWord(prefix: number[]): number[] {
  let i = prefix.length - 1;
  while (i >= 0 && prefix[i] !== SPACE) i--;
  return prefix.slice(i + 1);
}

type Beam = { prefix: number[]; pb: number; pnb: number };

/** prefix beam search: beam 12, top 8, lm 0.4, length bonus 0.6, word 0.2 */
export function prefixBeamDecode(
  lp: Float64Array,
  T: number,
  C: number,
  charset: string[],
  charLM: CharLMLike,
  words: WordLMLike,
): { text: string; score: number } {
  const BEAM = 12;
  const TOPK = 8;
  const LM_W = 0.4;
  const LEN_BONUS = 0.6;
  const WORD_W = 0.2;
  let beams: Beam[] = [{ prefix: [], pb: 0, pnb: -Infinity }];
  const keyOf = (p: number[]) => p.join(",");

  for (let t = 0; t < T; t++) {
    const row = t * C;
    const cands = topK(lp, row, C, TOPK);
    const next = new Map<string, Beam>();
    const getOrInsert = (prefix: number[]): Beam => {
      const k = keyOf(prefix);
      let e = next.get(k);
      if (!e) {
        e = { prefix, pb: -Infinity, pnb: -Infinity };
        next.set(k, e);
      }
      return e;
    };
    for (const beam of beams) {
      const ptot = lse(beam.pb, beam.pnb);
      for (const c of cands) {
        const p = lp[row + c];
        if (c === BLANK) {
          const e = getOrInsert(beam.prefix);
          e.pb = lse(e.pb, ptot + p);
          continue;
        }
        const last = beam.prefix.length ? beam.prefix[beam.prefix.length - 1] : -1;
        let src: number;
        if (last === c) {
          const e = getOrInsert(beam.prefix);
          e.pnb = lse(e.pnb, beam.pnb + p);
          src = beam.pb;
        } else {
          src = ptot;
        }
        if (src <= NEG_HALF) continue;
        const lw = lastWord(beam.prefix);
        let bonus = LM_W * charLM.logprob(beam.prefix, c) + LEN_BONUS;
        if (c === SPACE && lw.length) bonus += WORD_W * words.bonus(lw);
        const e2 = getOrInsert([...beam.prefix, c]);
        e2.pnb = lse(e2.pnb, src + p + bonus);
      }
    }
    const arr = [...next.values()];
    arr.sort((a, b) => {
      const sa = lse(a.pb, a.pnb);
      const sb = lse(b.pb, b.pnb);
      return sb > sa ? 1 : sb < sa ? -1 : 0;
    });
    beams = arr.slice(0, BEAM);
    if (!beams.length) beams = [{ prefix: [], pb: 0, pnb: -Infinity }];
  }

  let best: { prefix: number[]; score: number } | null = null;
  for (const b of beams) {
    const lw = lastWord(b.prefix);
    let s = lse(b.pb, b.pnb);
    if (lw.length) s += WORD_W * words.bonus(lw);
    if (!best || s > best.score) best = { prefix: b.prefix, score: s };
  }
  if (!best) return { text: "", score: -Infinity };
  return { text: best.prefix.map((i) => charset[i]).join(""), score: best.score };
}
