/**
 * עיבוד שורה לפי spec/preprocess.md של Mishkefet-v1:
 * אפור BT.601 → נרמול ניגודיות מקומי (Gaussian + percentiles) → שינוי גודל לגובה 64 → היפוך.
 */

export const LINE_HEIGHT = 64;
export type GrayImage = { data: Uint8Array; w: number; h: number };

export function roundU8(x: number): number {
  const v = Math.floor(x + 0.5);
  return v < 0 ? 0 : v > 255 ? 255 : v;
}

/** reflect101: ... 2 1 | 0 1 2 ... n-1 | n-2 ... */
function reflect101(i: number, n: number): number {
  if (n === 1) return 0;
  const period = 2 * (n - 1);
  let k = i % period;
  if (k < 0) k += period;
  return k < n ? k : period - k;
}

function roundHalfEven(x: number): number {
  const f = Math.floor(x);
  const d = x - f;
  if (d > 0.5) return f + 1;
  if (d < 0.5) return f;
  return f % 2 === 0 ? f : f + 1;
}

/** RGBA → אפור (PIL "L"): (R*19595 + G*38470 + B*7471 + 0x8000) >> 16 */
export function grayFromRgba(rgba: Uint8Array, w: number, h: number): Uint8Array {
  const out = new Uint8Array(w * h);
  for (let i = 0, p = 0; i < w * h; i++, p += 4) {
    out[i] = (rgba[p] * 19595 + rgba[p + 1] * 38470 + rgba[p + 2] * 7471 + 0x8000) >> 16;
  }
  return out;
}

function gaussianKernel(sigma: number): Float64Array {
  const ksize = Math.floor(sigma * 6 + 1 + 0.5) | 1;
  const r = (ksize - 1) / 2;
  const k = new Float64Array(ksize);
  let sum = 0;
  for (let i = 0; i < ksize; i++) {
    const x = i - r;
    k[i] = Math.exp(-(x * x) / (2 * sigma * sigma));
    sum += k[i];
  }
  for (let i = 0; i < ksize; i++) k[i] /= sum;
  return k;
}

function blurReflect(src: Uint8Array, w: number, h: number, sigma: number): Uint8Array {
  const k = gaussianKernel(sigma);
  const r = (k.length - 1) / 2;
  const tmp = new Float64Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let acc = 0;
      for (let i = 0; i < k.length; i++) acc += k[i] * src[y * w + reflect101(x + i - r, w)];
      tmp[y * w + x] = acc;
    }
  }
  const out = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let acc = 0;
      for (let i = 0; i < k.length; i++) acc += k[i] * tmp[reflect101(y + i - r, h) * w + x];
      out[y * w + x] = roundU8(acc);
    }
  }
  return out;
}

function percentile(sorted: Float64Array, q: number): number {
  const n = sorted.length;
  const pos = (q / 100) * (n - 1);
  const i0 = Math.floor(pos);
  const i1 = Math.min(i0 + 1, n - 1);
  const frac = pos - i0;
  return sorted[i0] + (sorted[i1] - sorted[i0]) * frac;
}

/** נרמול ניגודיות מקומי ברזולוציה המקורית של השורה */
function contrastNormalize(gray: Uint8Array, w: number, h: number): Uint8Array {
  const sigma = Math.max(h / 8, 3);
  const blur = blurReflect(gray, w, h, sigma);
  const n = w * h;
  const flat = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    flat[i] = Math.fround(gray[i] / Math.max(blur[i], 1e-3));
  }
  const sorted = Float64Array.from(flat).sort();
  const lo = percentile(sorted, 2);
  const hi = percentile(sorted, 98);
  const out = new Uint8Array(n);
  if (hi - lo < 1e-6) {
    out.fill(255);
    return out;
  }
  for (let i = 0; i < n; i++) {
    const v = ((flat[i] - lo) / (hi - lo)) * 255;
    out[i] = Math.trunc(v < 0 ? 0 : v > 255 ? 255 : v);
  }
  return out;
}

type Tap = { idx: number[]; w: number[] };

function areaTaps(srcN: number, dstN: number): Tap[] {
  const s = srcN / dstN;
  const taps: Tap[] = [];
  for (let i = 0; i < dstN; i++) {
    const a = i * s;
    const b = (i + 1) * s;
    const idx: number[] = [];
    const ws: number[] = [];
    let total = 0;
    for (let j = Math.floor(a); j < Math.ceil(b) && j < srcN; j++) {
      const ov = Math.min(b, j + 1) - Math.max(a, j);
      if (ov > 0) {
        idx.push(j);
        ws.push(ov);
        total += ov;
      }
    }
    for (let k = 0; k < ws.length; k++) ws[k] /= total;
    taps.push({ idx, w: ws });
  }
  return taps;
}

function bilinearTaps(srcN: number, dstN: number): Tap[] {
  const s = srcN / dstN;
  const taps: Tap[] = [];
  for (let i = 0; i < dstN; i++) {
    const f = (i + 0.5) * s - 0.5;
    let j = Math.floor(f);
    let a = f - j;
    if (j < 0) {
      j = 0;
      a = 0;
    } else if (j >= srcN - 1) {
      j = srcN - 1;
      a = 0;
    }
    if (a === 0 || j >= srcN - 1) taps.push({ idx: [j], w: [1] });
    else taps.push({ idx: [j, j + 1], w: [1 - a, a] });
  }
  return taps;
}

/** שינוי גודל הפרדה: אנכי ואז אופקי, בדיוק כפי שמתואר ב-spec */
function resample2d(src: Float64Array, sw: number, sh: number, tx: Tap[], ty: Tap[]): Float64Array {
  const dh = ty.length;
  const dw = tx.length;
  const tmp = new Float64Array(dh * sw);
  for (let oy = 0; oy < dh; oy++) {
    const tap = ty[oy];
    for (let x = 0; x < sw; x++) {
      let acc = 0;
      for (let k = 0; k < tap.idx.length; k++) acc += tap.w[k] * src[tap.idx[k] * sw + x];
      tmp[oy * sw + x] = acc;
    }
  }
  const out = new Float64Array(dh * dw);
  for (let oy = 0; oy < dh; oy++) {
    for (let ox = 0; ox < dw; ox++) {
      const tap = tx[ox];
      let acc = 0;
      for (let k = 0; k < tap.idx.length; k++) acc += tap.w[k] * tmp[oy * sw + tap.idx[k]];
      out[oy * dw + ox] = acc;
    }
  }
  return out;
}

/** קלט מודל: float32 (64, W), דיו קרוב ל-1, נייר קרוב ל-0 */
export function preprocess(img: GrayImage): { data: Float32Array; w: number } {
  const { w, h } = img;
  const norm = contrastNormalize(img.data, w, h);
  const scale = LINE_HEIGHT / h;
  const dh = LINE_HEIGHT;
  const dw = Math.min(2560, Math.max(16, roundHalfEven(w * scale)));
  const mode = scale < 1 ? "area" : "bilinear";
  const tx = mode === "area" ? areaTaps(w, dw) : bilinearTaps(w, dw);
  const ty = mode === "area" ? areaTaps(h, dh) : bilinearTaps(h, dh);
  const res = resample2d(Float64Array.from(norm), w, h, tx, ty);
  const data = new Float32Array(dh * dw);
  for (let i = 0; i < data.length; i++) {
    const g = roundU8(res[i]);
    data[i] = 1 - Math.fround(g / 255);
  }
  return { data, w: dw };
}

function cubic(x: number): number {
  const a = -0.5;
  const ax = Math.abs(x);
  if (ax < 1) return ((a + 2) * ax - (a + 3)) * ax * ax + 1;
  if (ax < 2) return ((a * ax - 5 * a) * ax + 8 * a) * ax - 4 * a;
  return 0;
}

/** תצוגת TTA: שינוי רוחב בלבד בביקוביק (כמו PIL BICUBIC) */
export function ttaView(img: GrayImage, s: number): GrayImage {
  if (s === 1) return img;
  const { w, h } = img;
  const newW = Math.max(8, Math.trunc(w * s));
  const scale = w / newW;
  const fscale = Math.max(scale, 1);
  const support = 2 * fscale;
  const out = new Uint8Array(newW * h);
  for (let i = 0; i < newW; i++) {
    const centre = (i + 0.5) * scale;
    const lo = Math.max(Math.trunc(centre - support + 0.5), 0);
    const hi = Math.min(Math.trunc(centre + support + 0.5), w);
    const idx: number[] = [];
    const ws: number[] = [];
    let total = 0;
    for (let j = lo; j < hi; j++) {
      const wt = cubic((j - centre + 0.5) / fscale);
      idx.push(j);
      ws.push(wt);
      total += wt;
    }
    if (total === 0) continue;
    for (let k = 0; k < ws.length; k++) ws[k] /= total;
    for (let y = 0; y < h; y++) {
      let acc = 0;
      for (let k = 0; k < idx.length; k++) acc += ws[k] * img.data[y * w + idx[k]];
      out[y * newW + i] = roundU8(acc);
    }
  }
  return { data: out, w: newW, h };
}
