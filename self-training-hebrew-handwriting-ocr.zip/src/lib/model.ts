import { BM_CELLS, base64ToBytes, bitsToWords, packBitsToWords, similarityWords, unpackBitmap } from "./bitmap";
import { editDistance, fixMidFinals, isWordChar, normalizeForMatch, stripNiqqud } from "./hebrew";

export type GlyphCandidate = { label: string; score: number };
export type GlyphSample = { label: string; bitmap: string; aspect: number };

export type ModelPayload = {
  version: number;
  trainedAt: string;
  samples: number;
  accuracy: number;
  classes: { label: string; count: number; prior: number; cells: string }[];
  templates: GlyphSample[];
  lang: {
    words: [string, number][];
    bigrams: string[];
    chars: [string, number][];
    subs: [string, string, number][];
  };
};

/* ------------------------------- מודל גליפים ------------------------------- */

type CompiledClass = { label: string; prior: number; p: Float32Array };
type CompiledTemplate = { label: string; words: Uint32Array; aspect: number };

const KNN_WEIGHT = 34;
const ASPECT_WEIGHT = 5;
const SOFTMAX_TEMP = 14;

export class GlyphModel {
  private classes: CompiledClass[] = [];
  private templates: CompiledTemplate[] = [];
  readonly version: number;
  readonly samples: number;
  readonly accuracy: number;
  readonly trainedAt: string;

  constructor(payload: ModelPayload | null) {
    this.version = payload?.version ?? 0;
    this.samples = payload?.samples ?? 0;
    this.accuracy = payload?.accuracy ?? 0;
    this.trainedAt = payload?.trainedAt ?? "";
    if (payload) {
      for (const c of payload.classes) {
        const raw = base64ToBytes(c.cells);
        const p = new Float32Array(BM_CELLS);
        for (let i = 0; i < BM_CELLS; i++) p[i] = (raw[i] ?? 0) / 255;
        this.classes.push({ label: c.label, prior: c.prior, p });
      }
      for (const t of payload.templates) {
        this.templates.push({ label: t.label, words: bitsToWords(t.bitmap), aspect: t.aspect });
      }
    }
  }

  get ready(): boolean {
    return this.classes.length > 0;
  }

  get labels(): string[] {
    return this.classes.map((c) => c.label);
  }

  /** מחזיר 5 המועמדים המובילים לגליף */
  classify(bitmap: string, aspect: number, topK = 5): GlyphCandidate[] {
    if (!this.classes.length) return [];
    const bits = unpackBitmap(bitmap);
    const scored = this.classes.map((c) => {
      let logLik = Math.log(Math.max(1e-6, c.prior));
      for (let i = 0; i < BM_CELLS; i++) {
        const pi = c.p[i] * 0.96 + 0.02;
        logLik += bits[i] ? Math.log(pi) : Math.log(1 - pi);
      }
      return { label: c.label, logLik };
    });
    // שכנים קרובים (kNN) על כל הדגימות שנאספו מהכתב הספציפי
    const byLabel = new Map<string, number>();
    if (this.templates.length) {
      const glyphWords = packBitsToWords(bits);
      for (const t of this.templates) {
        const sim = similarityWords(glyphWords, t.words);
        const aspectSim = 1 - Math.min(1, Math.abs(t.aspect - aspect) / 1.4);
        const s = sim + 0.12 * aspectSim;
        const cur = byLabel.get(t.label) ?? 0;
        if (s > cur) byLabel.set(t.label, s);
      }
    }
    const final = scored
      .map((s) => {
        const knn = byLabel.get(s.label) ?? 0;
        return { label: s.label, score: s.logLik + KNN_WEIGHT * knn };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, topK);
    if (!final.length) return [];
    const max = final[0].score;
    const exps = final.map((f) => Math.exp((f.score - max) / SOFTMAX_TEMP));
    const sum = exps.reduce((a, b) => a + b, 0) || 1;
    return final.map((f, i) => ({ label: f.label, score: Math.log(exps[i] / sum) }));
  }
}

/* ------------------------------ מודל שפה קטן ------------------------------ */

const UNK_PAD = "\u0002";
const EOS = "\u0003";
const CHAR_LAMBDA = 0.16;
const LEXICON_BONUS = 2.6;
const DELETE_PENALTY = 1.15;

export class LanguageModel {
  words = new Map<string, number>();
  private bigrams = new Map<string, number>();
  private c3 = new Map<string, number>();
  private c2 = new Map<string, number>();
  private c1 = new Map<string, number>();
  private subs = new Map<string, string>();
  private totalWords = 0;
  private totalChars = 0;
  private vocabSize = 40;
  private bigramCount = 0;
  version = 0;

  constructor(lang: ModelPayload["lang"] | undefined, version = 0) {
    this.version = version;
    if (!lang) return;
    for (const [w, c] of lang.words) {
      this.words.set(w, (this.words.get(w) ?? 0) + c);
      this.totalWords += c;
    }
    for (const b of lang.bigrams) {
      const i = b.lastIndexOf("|");
      if (i <= 0) continue;
      const w1 = b.slice(0, i);
      const rest = b.slice(i + 1);
      const j = rest.lastIndexOf("|");
      if (j < 0) continue;
      this.bigrams.set(w1 + "\u0001" + rest.slice(0, j), Number(rest.slice(j + 1)) || 0);
      this.bigramCount++;
    }
    for (const [n, c] of lang.chars) {
      this.totalChars += c;
      if (n.length === 3) this.c3.set(n, (this.c3.get(n) ?? 0) + c);
      if (n.length === 2) this.c2.set(n, (this.c2.get(n) ?? 0) + c);
      if (n.length === 1) this.c1.set(n, (this.c1.get(n) ?? 0) + c);
    }
    for (const [wrong, right, c] of lang.subs) {
      const cur = this.subs.get(wrong);
      if (!cur || (this.words.get(right) ?? 0) > (this.words.get(cur) ?? 0)) this.subs.set(wrong, right);
    }
    const chars = new Set<string>();
    for (const n of this.c1.keys()) chars.add(n);
    for (const n of this.c3.keys()) {
      for (const ch of n) chars.add(ch);
    }
    this.vocabSize = Math.max(24, chars.size + 4);
  }

  get lexiconSize(): number {
    return this.words.size;
  }

  isKnown(word: string): boolean {
    return this.words.has(word) || this.words.has(normalizeForMatch(word));
  }

  wordLogProb(word: string): number {
    const c = this.words.get(word) ?? 0;
    return Math.log((c + 0.12) / (this.totalWords + 0.12 * 5000));
  }

  bigramLogProb(w1: string, w2: string): number {
    const c = this.bigrams.get(w1 + "\u0001" + w2) ?? 0;
    const denom = this.bigramCount;
    if (c > 0) return Math.log((c + 0.15) / (60 + 0.15 * denom));
    return Math.log(0.15 / (60 + 0.15 * denom)) + (this.isKnown(w2) ? 0 : -0.35);
  }

  /** הסתברות תווית של מילה (trigram תווים עם backoff) */
  charLogProb(word: string): number {
    const s = UNK_PAD + UNK_PAD + stripNiqqud(word) + EOS;
    let total = 0;
    for (let i = 2; i < s.length; i++) {
      const ctx = s.slice(i - 2, i);
      const c = s[i];
      const c2 = this.c2.get(ctx) ?? 0;
      let p: number;
      if (c2 > 0) {
        p = ((this.c3.get(ctx + c) ?? 0) + 0.18) / (c2 + 0.18 * this.vocabSize);
      } else {
        p = ((this.c1.get(c) ?? 0) + 0.18) / (this.totalChars + 0.18 * this.vocabSize);
      }
      total += Math.log(Math.max(1e-8, p));
    }
    return total;
  }

  applySubstitutions(text: string): string {
    return text
      .split(/(\s+)/)
      .map((tok) => {
        if (!tok || /^\s+$/.test(tok)) return tok;
        const sub = this.subs.get(tok);
        return sub ?? tok;
      })
      .join("");
  }

  /** הצעות תיקון למילה בודדת מתוך המילון שנלמד (שמרני: רק מרחק עריכה קטן ומילה נפוצה) */
  suggest(word: string, limit = 4): { word: string; score: number }[] {
    const target = stripNiqqud(word);
    if (!target || this.isKnown(target)) return [];
    const maxD = Math.max(1, Math.floor(target.length / 3));
    const out: { word: string; score: number }[] = [];
    for (const [w, c] of this.words) {
      if (c < 2) continue;
      const d = editDistance(target, w, maxD);
      if (d > maxD) continue;
      out.push({ word: w, score: Math.log(c + 1) - 2.2 * d - 0.4 * Math.abs(w.length - target.length) });
    }
    return out.sort((a, b) => b.score - a.score).slice(0, limit);
  }

  /** חיפוש קורות: בונה מועמדי מילים מרשימת המועמדים של כל גליף */
  beamWords(glyphs: GlyphCandidate[][], beamWidth = 14): { word: string; score: number }[] {
    if (!glyphs.length) return [];
    type State = { s: string; score: number; logp: number };
    let beam: State[] = [{ s: "", score: 0, logp: 0 }];
    for (const cands of glyphs) {
      const next: State[] = [];
      for (const st of beam) {
        if (cands.length === 0) {
          next.push({ s: st.s + "?", score: st.score - 2.2, logp: st.logp });
          continue;
        }
        for (const c of cands) {
          const s = st.s + c.label;
          if (s.length > 22) continue;
          next.push({
            s,
            score: st.score + c.score + CHAR_LAMBDA * this.charLogProb(s) + (this.isKnown(s) ? LEXICON_BONUS : 0),
            logp: st.logp + c.score,
          });
        }
        next.push({ s: st.s, score: st.score - DELETE_PENALTY, logp: st.logp });
      }
      next.sort((a, b) => b.score - a.score);
      beam = next.slice(0, beamWidth);
    }
    const seen = new Set<string>();
    const out: { word: string; score: number }[] = [];
    for (const st of beam) {
      if (!st.s || seen.has(st.s)) continue;
      seen.add(st.s);
      out.push({ word: st.s, score: st.score });
    }
    return out.slice(0, 8);
  }

  /** Viterbi על שורה: בוחר את המילה הטובה בכל מקום לפי הקשר צמדים */
  bestSentence(words: { cands: { word: string; score: number }[]; fixed?: string }[]): string[] {
    type State = { prev: string; score: number; path: string[] };
    let states: State[] = [{ prev: "", score: 0, path: [] }];
    for (const w of words) {
      const options: string[] = w.fixed ? [w.fixed] : (w.cands.length ? w.cands : [{ word: "?", score: -3 }]).map((c) => c.word);
      const scores = new Map<string, number>();
      if (!w.fixed) for (const c of w.cands) scores.set(c.word, c.score);
      const next: State[] = [];
      const byPrev = new Map<string, State>();
      for (const st of states) {
        for (const o of options) {
          const local = w.fixed ? 0 : (scores.get(o) ?? -3);
          const s = st.score + local + (st.prev ? this.bigramLogProb(st.prev, o) : this.isKnown(o) ? 0.3 : -0.2);
          const cur = byPrev.get(o);
          if (!cur || cur.score < s) byPrev.set(o, { prev: o, score: s, path: [...st.path, o] });
        }
      }
      for (const st of byPrev.values()) next.push(st);
      next.sort((a, b) => b.score - a.score);
      states = next.slice(0, 6);
    }
    if (!states.length) return [];
    return states[0].path;
  }

  /** תיקון טקסט חופשי בעזרת המילון (משמש גם לתיקון פלט של OCR חיצוני) */
  correctFreeText(text: string): string {
    if (!this.words.size) return text;
    const tokens = text.split(/(\s+)/);
    return tokens
      .map((tok) => {
        if (!tok || /^\s+$/.test(tok)) return tok;
        const bare = tok.replace(/[^\p{L}\p{N}'"]/gu, "");
        if (!bare || !isWordChar(bare[0])) return tok;
        const fixed = fixMidFinals(bare);
        if (this.isKnown(fixed)) return tok.replace(bare, fixed);
        const sub = this.subs.get(fixed);
        if (sub) return tok.replace(bare, sub);
        const sugg = this.suggest(fixed, 1);
        if (sugg.length) {
          return tok.replace(bare, sugg[0].word);
        }
        return tok.replace(bare, fixed);
      })
      .join("");
  }
}

/* ---------------------------- יצירת המודל המאוחד --------------------------- */

export function buildRecognizer(payload: ModelPayload | null): { glyph: GlyphModel; lang: LanguageModel } {
  return { glyph: new GlyphModel(payload), lang: new LanguageModel(payload?.lang, payload?.version ?? 0) };
}

/** מזג מועמדי גליף מהמודל המקומי עם טקסט OCR חיצוני לאותו גליף (אם קיים) */
export function boostWithExternal(oracle: string | null, candidates: GlyphCandidate[]): GlyphCandidate[] {
  if (!oracle || !candidates.length) return candidates;
  const hit = candidates.find((c) => normalizeForMatch(c.label) === normalizeForMatch(oracle));
  if (hit) {
    return [{ label: oracle, score: Math.min(hit.score, -0.05) }, ...candidates.filter((c) => c !== hit)];
  }
  return [{ label: oracle, score: -0.9 }, ...candidates];
}
