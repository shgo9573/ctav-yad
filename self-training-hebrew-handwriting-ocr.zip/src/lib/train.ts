import { db } from "@/db";
import { glyphs, lmBigrams, lmChars, lmWords, modelVersions, substitutions } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import { BM_CELLS, bytesToBase64, packBitsToWords, similarityWords, unpackBitmap } from "./bitmap";
import type { ModelPayload } from "./model";

const MAX_TEMPLATES_PER_LABEL = 10;
const MAX_TEMPLATES = 1600;

type Sample = { bitmap: string; aspect: number };

function pickTemplates(samples: Sample[], limit: number): Sample[] {
  if (samples.length <= limit) return samples.slice();
  const words = samples.map((s) => packBitsToWords(unpackBitmap(s.bitmap)));
  const chosen: number[] = [0];
  while (chosen.length < limit) {
    let bestIdx = -1;
    let bestDist = -1;
    for (let i = 0; i < samples.length; i++) {
      let closest = 2;
      for (const c of chosen) {
        const d = 1 - similarityWords(words[i], words[c]);
        if (d < closest) closest = d;
      }
      if (closest > bestDist) {
        bestDist = closest;
        bestIdx = i;
      }
    }
    if (bestIdx < 0 || bestDist < 0.02) break;
    chosen.push(bestIdx);
  }
  return chosen.map((i) => samples[i]);
}

/** אימון מלא: בונה snapshot חדש מכל הגליפים המתויגים + מודל השפה, ושומר גרסה */
export async function trainModel(note = ""): Promise<{
  version: number;
  samples: number;
  classes: number;
  accuracy: number;
  createdAt: string;
}> {
  const rows = await db
    .select({ label: glyphs.label, bitmap: glyphs.bitmap, aspect: glyphs.aspect })
    .from(glyphs)
    .orderBy(desc(glyphs.id))
    .limit(40000);

  const byLabel = new Map<string, Sample[]>();
  const seen = new Set<string>();
  for (const r of rows) {
    if (!r.label || !r.bitmap) continue;
    const key = `${r.label}|${r.bitmap}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const arr = byLabel.get(r.label) ?? [];
    arr.push({ bitmap: r.bitmap, aspect: r.aspect });
    byLabel.set(r.label, arr);
  }

  const totalSamples = [...byLabel.values()].reduce((a, b) => a + b.length, 0);
  const classes: ModelPayload["classes"] = [];
  for (const [label, samples] of byLabel) {
    const n = samples.length;
    const ink = new Float64Array(BM_CELLS);
    for (const s of samples) {
      const bits = unpackBitmap(s.bitmap);
      for (let i = 0; i < BM_CELLS; i++) ink[i] += bits[i];
    }
    const bytes = new Uint8Array(BM_CELLS);
    for (let i = 0; i < BM_CELLS; i++) {
      const p = (ink[i] + 0.6) / (n + 1.2);
      bytes[i] = Math.max(1, Math.min(254, Math.round(p * 255)));
    }
    classes.push({
      label,
      count: n,
      prior: totalSamples ? n / totalSamples : 0,
      cells: bytesToBase64(bytes),
    });
  }
  classes.sort((a, b) => b.count - a.count);

  const templates: ModelPayload["templates"] = [];
  for (const [label, samples] of byLabel) {
    for (const s of pickTemplates(samples, MAX_TEMPLATES_PER_LABEL)) {
      templates.push({ label, bitmap: s.bitmap, aspect: s.aspect });
    }
  }
  // הגבלה על מספר התבניות הכולל (שומרים מגוון)
  const trimmed = templates.length > MAX_TEMPLATES ? templates.slice(0, MAX_TEMPLATES) : templates;

  const wordRows = await db.select().from(lmWords).orderBy(desc(lmWords.count)).limit(6000);
  const bigramRows = await db.select().from(lmBigrams).orderBy(desc(lmBigrams.count)).limit(15000);
  const charRows = await db.select().from(lmChars).orderBy(desc(lmChars.count)).limit(20000);
  const subRows = await db.select().from(substitutions).orderBy(desc(substitutions.count)).limit(3000);

  const payload: ModelPayload = {
    version: 0,
    trainedAt: new Date().toISOString(),
    samples: totalSamples,
    accuracy: 0,
    classes,
    templates: trimmed,
    lang: {
      words: wordRows.map((w) => [w.word, w.count] as [string, number]),
      bigrams: bigramRows.map((b) => `${b.w1}|${b.w2}|${b.count}`),
      chars: charRows.map((c) => [c.ngram, c.count] as [string, number]),
      subs: subRows.map((s) => [s.wrong, s.right, s.count] as [string, string, number]),
    },
  };

  // הערכת דיוק בשיטת שכן קרוב (leave-one-out) על תת-קבוצת התבניות
  const evalSet = trimmed.slice(0, 700).map((t) => ({
    label: t.label,
    words: packBitsToWords(unpackBitmap(t.bitmap)),
  }));
  let correct = 0;
  let evaluated = 0;
  for (let i = 0; i < evalSet.length; i++) {
    let best = -1;
    let bestLabel = "";
    for (let j = 0; j < evalSet.length; j++) {
      if (i === j) continue;
      const sim = similarityWords(evalSet[i].words, evalSet[j].words);
      if (sim > best) {
        best = sim;
        bestLabel = evalSet[j].label;
      }
    }
    evaluated++;
    if (bestLabel === evalSet[i].label) correct++;
  }
  payload.accuracy = evaluated ? correct / evaluated : 0;

  const [latest] = await db
    .select({ version: modelVersions.version })
    .from(modelVersions)
    .orderBy(desc(modelVersions.version))
    .limit(1);
  const version = (latest?.version ?? 0) + 1;
  payload.version = version;

  await db.insert(modelVersions).values({
    version,
    samples: totalSamples,
    classes: classes.length,
    accuracy: payload.accuracy,
    payload,
    note,
  });

  return { version, samples: totalSamples, classes: classes.length, accuracy: payload.accuracy, createdAt: payload.trainedAt };
}

export async function countGlyphs(): Promise<number> {
  const [row] = await db.select({ c: sql<number>`count(*)::int` }).from(glyphs);
  return Number(row?.c ?? 0);
}
