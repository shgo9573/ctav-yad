export type SaveLinePayload = {
  idx: number;
  x: number;
  y: number;
  w: number;
  h: number;
  imageBase64: string;
  rawText: string;
  text: string;
  status: string;
  confidence: number;
};

export type LineRecord = {
  id: number;
  idx: number;
  x: number;
  y: number;
  w: number;
  h: number;
  imageBase64: string | null;
  rawText: string;
  text: string;
  status: string;
  confidence: number;
};

export type DocumentSummary = {
  id: number;
  name: string;
  width: number;
  height: number;
  createdAt: string;
  lineCount: number;
};

export type DocumentDetail = {
  id: number;
  name: string;
  width: number;
  height: number;
  createdAt: string;
  lines: LineRecord[];
};

export type GlyphPayload = {
  label: string;
  bitmap: string;
  aspect: number;
  gx?: number;
  spaceBefore?: boolean;
  source?: string;
};

export type RecognizeResult = { text: string; confidence: number };

/** תוצאת סבב אימון של ראש המודל (CTC) */
export type RoundInfo = {
  round: number;
  accepted: boolean;
  reason: string;
  trainSamples: number;
  heldOut: number;
  accBefore: number | null;
  accAfter: number | null;
  loss0: number;
  loss1: number;
  steps: number;
  durationMs: number;
  at: string;
};

export type AdaptJob = {
  running: boolean;
  phase: string;
  step: number;
  steps: number;
  samples: number;
  startedAt: string | null;
  finishedAt: string | null;
  error: string | null;
  result: RoundInfo | null;
};

export type AdaptStatus = {
  job: AdaptJob;
  head: { round: number; file: string | null };
  rounds: RoundInfo[];
  dataset: { dir: string; lines: number; pages: number; trainable: number };
  base: { name: string; classes: number; license: string };
};
