import type { Box } from "./vision";
import { flattenTessBlocks, type TessLine } from "./ocrParse";

export type { TessLine } from "./ocrParse";

export type LooseWorker = {
  recognize: (image: unknown, options?: unknown, output?: unknown) => Promise<{ data: { text?: string; blocks?: unknown } }>;
  setParameters: (params: Record<string, string>) => Promise<unknown>;
  terminate: () => Promise<unknown>;
};

export type OcrEngine = "mishkefet" | "server" | "browser" | "none";

const BROWSER_OCR_TIMEOUT_MS = 90_000;
const SERVER_OCR_TIMEOUT_MS = 120_000;

/** הופך כל ערך שנזרק (Error, ErrorEvent, DOMException, אובייקט, מחרוזת) להודעה קריאה */
export function describeError(err: unknown): string {
  if (err instanceof Error) return err.message || err.name || "שגיאה";
  if (typeof ErrorEvent !== "undefined" && err instanceof ErrorEvent) {
    const where = err.filename ? ` (${err.filename}:${err.lineno})` : "";
    return `${err.message || "שגיאת Worker"}${where}`;
  }
  if (typeof err === "string") return err;
  if (err && typeof err === "object") {
    const o = err as Record<string, unknown>;
    if (typeof o.message === "string" && o.message) return o.message;
    if (typeof o.type === "string") return `אירוע ${o.type}`;
    try {
      return JSON.stringify(err).slice(0, 200);
    } catch {
      /* ignore */
    }
  }
  return "שגיאה לא ידועה";
}

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = window.setTimeout(() => reject(new Error(`${label}: פג זמן ההמתנה (${ms / 1000} שניות)`)), ms);
    promise.then(
      (v) => {
        window.clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        window.clearTimeout(timer);
        reject(e);
      },
    );
  });
}

/** OCR בשרת המקומי — עובד בכל דפדפן, בלי Web Worker */
export async function serverOcr(canvas: HTMLCanvasElement): Promise<TessLine[]> {
  const imageBase64 = canvas.toDataURL("image/jpeg", 0.92).split(",")[1] ?? "";
  const res = await withTimeout(
    fetch("/api/ocr", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ imageBase64 }),
    }),
    SERVER_OCR_TIMEOUT_MS,
    "OCR בשרת",
  );
  const data = (await res.json().catch(() => ({}))) as { lines?: TessLine[]; error?: string };
  if (!res.ok || !data.lines) throw new Error(data.error || `HTTP ${res.status}`);
  return data.lines;
}

/** OCR גיבוי בדפדפן: tesseract.js עם worker/WASM/tessdata מתוך public/ */
export async function browserOcr(canvas: HTMLCanvasElement, onProgress?: (status: string, progress: number) => void): Promise<TessLine[]> {
  const mod = await import("tesseract.js");
  const worker = (await withTimeout(
    mod.createWorker("heb", 1, {
      workerPath: "/tesseract/worker.min.js",
      corePath: "/tesseract",
      langPath: "/tessdata",
      gzip: false,
      logger: (m: { status: string; progress: number }) => onProgress?.(m.status, m.progress),
    }),
    BROWSER_OCR_TIMEOUT_MS,
    "טעינת OCR בדפדפן",
  )) as unknown as LooseWorker;
  try {
    await worker.setParameters({ tessedit_pageseg_mode: "4" });
    const res = await withTimeout(
      worker.recognize(canvas, {}, { text: true, blocks: true }),
      BROWSER_OCR_TIMEOUT_MS,
      "זיהוי טקסט בדפדפן",
    );
    return flattenTessBlocks(res.data.blocks);
  } finally {
    try {
      await worker.terminate();
    } catch {
      /* ignore */
    }
  }
}

function overlapRatio(a: Box, b: Box): number {
  const ix0 = Math.max(a.x, b.x);
  const iy0 = Math.max(a.y, b.y);
  const ix1 = Math.min(a.x + a.w, b.x + b.w);
  const iy1 = Math.min(a.y + a.h, b.y + b.h);
  if (ix1 <= ix0 || iy1 <= iy0) return 0;
  const inter = (ix1 - ix0) * (iy1 - iy0);
  return inter / Math.min(a.w * a.h, Math.max(1, b.w * b.h));
}

export function matchTessText(detected: Box[], tess: TessLine[]): (string | null)[] {
  return detected.map((d) => {
    let best: string | null = null;
    let bestScore = 0;
    for (const t of tess) {
      const score = overlapRatio(d, t.box);
      if (score > bestScore) {
        bestScore = score;
        best = t.text;
      }
    }
    return bestScore > 0.25 ? best : null;
  });
}
